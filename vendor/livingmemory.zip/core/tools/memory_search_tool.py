"""供 Agent 主动调用的长期记忆回忆工具。"""

import asyncio
import json
from dataclasses import field
from typing import Any

from pydantic.dataclasses import dataclass

from astrbot.api import logger
from astrbot.core.agent.run_context import ContextWrapper
from astrbot.core.agent.tool import FunctionTool, ToolExecResult
from astrbot.core.astr_agent_context import AstrAgentContext

from ..base.config_manager import ConfigManager
from ..memory_scope import is_event_memory_allowed, resolve_memory_scope
from ..utils import get_persona_id


def _json_result(data: dict[str, Any]) -> str:
    """将工具结果稳定序列化为 JSON 文本。"""
    return json.dumps(data, ensure_ascii=False, default=str)


@dataclass
class MemorySearchTool(FunctionTool[AstrAgentContext]):
    """长期记忆主动回忆工具。"""

    __pydantic_config__ = {"arbitrary_types_allowed": True}

    context: Any = None
    config_manager: ConfigManager | None = None
    memory_engine: Any = None

    name: str = "recall_long_term_memory"
    description: str = (
        "Recall long-term memory when the current context is insufficient. "
        "Use concise, focused recall keywords instead of copying the full user message. "
        "Call this when the user asks you to recall prior facts, preferences, agreements, or older context, "
        "or when resolving ambiguous references requires checking memory. "
        "Prefer short topic phrases, named entities, preferences, commitments, or past events as recall keywords. "
        "If the first recall is not enough, refine the keywords and recall again."
    )
    parameters: dict[str, Any] = field(
        default_factory=lambda: {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Concise recall keywords for long-term memory. Prefer key entities, topics, preferences, commitments, or past events instead of copying the full user message.",
                },
                "k": {
                    "type": "integer",
                    "description": "Maximum number of memory items to return for one recall. Keep this small unless more evidence is needed.",
                    "default": 5,
                },
                "include_source": {
                    "type": "boolean",
                    "description": "Include retained original messages when exact details are needed. Use only after normal recall is insufficient.",
                    "default": False,
                },
            },
            "required": ["query"],
        }
    )

    async def call(
        self,
        context: ContextWrapper[AstrAgentContext],
        query: str,
        k: int = 5,
        include_source: bool = False,
    ) -> ToolExecResult:
        """执行长期记忆回忆。"""
        cleaned_query = (query or "").strip()
        if not cleaned_query:
            return _json_result(
                {
                    "query": "",
                    "count": 0,
                    "results": [],
                    "error": "query is empty",
                }
            )

        if (
            self.config_manager is None
            or self.memory_engine is None
            or self.context is None
        ):
            return _json_result(
                {
                    "query": cleaned_query,
                    "count": 0,
                    "results": [],
                    "error": "memory search tool is not initialized",
                }
            )

        try:
            event = context.context.event
            if not is_event_memory_allowed(self.config_manager, event):
                return _json_result(
                    {
                        "query": cleaned_query,
                        "count": 0,
                        "results": [],
                        "error": "memory access is not allowed",
                    }
                )
            filtering_config = self.config_manager.filtering_settings
            use_persona_filtering = filtering_config.get("use_persona_filtering", True)

            persona_id = (
                await get_persona_id(self.context, event)
                if use_persona_filtering
                else None
            )

            # 作用域解析失败时回退到原始会话，与写入侧（反思/总结/工具）保持一致
            recall_scope = resolve_memory_scope(self.config_manager, event)
            recall_session_id = recall_scope or event.unified_msg_origin
            # session_filtered 只表示本次查询是否真的按会话隔离：global / user
            # 作用域跨会话共享，legacy 未启用会话过滤（scope 为 None）也不是会话
            # 过滤；只有解析出的作用域就是当前会话 ID 时才为 True，避免误报
            # “会话隔离仍然生效”而干扰排查。
            session_filtered = (
                recall_scope is not None and recall_scope == event.unified_msg_origin
            )
            recall_persona_id = persona_id if use_persona_filtering else None

            default_k = int(self.config_manager.get("recall_engine.top_k", 5))
            max_k = int(self.config_manager.get("recall_engine.max_k", 10))
            requested_k = default_k if k is None else k
            try:
                requested_k_int = int(requested_k)
            except (TypeError, ValueError):
                requested_k_int = default_k

            limited_k = max(1, min(requested_k_int, max_k))

            memories = await self.memory_engine.search_memories(
                query=cleaned_query,
                k=limited_k,
                session_id=recall_session_id,
                persona_id=recall_persona_id,
            )

            serialized_results = []
            for memory in memories:
                metadata = memory.metadata if isinstance(memory.metadata, dict) else {}
                item = {
                    "id": memory.doc_id,
                    "content": memory.content,
                    "score": memory.final_score,
                    "importance": metadata.get("importance"),
                    "session_id": metadata.get("session_id"),
                    "persona_id": metadata.get("persona_id"),
                    "create_time": metadata.get("create_time"),
                    "last_access_time": metadata.get("last_access_time"),
                }
                if include_source and metadata.get("has_source"):
                    get_source = getattr(
                        self.memory_engine, "get_memory_source", None
                    )
                    if callable(get_source):
                        item["source_messages"] = await get_source(memory.doc_id)
                serialized_results.append(item)

            return _json_result(
                {
                    "query": cleaned_query,
                    "applied_filters": {
                        "session_filtered": session_filtered,
                        "persona_filtered": use_persona_filtering,
                    },
                    "count": len(serialized_results),
                    "results": serialized_results,
                }
            )
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.error(f"记忆工具检索失败: {e}", exc_info=True)
            return _json_result(
                {
                    "query": cleaned_query,
                    "count": 0,
                    "results": [],
                    "error": "internal_error",
                }
            )
