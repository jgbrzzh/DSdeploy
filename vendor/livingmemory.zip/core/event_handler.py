"""
事件处理器
负责处理AstrBot事件钩子
"""

import asyncio
from typing import Any

from astrbot.api import logger
from astrbot.api.event import AstrMessageEvent
from astrbot.api.provider import LLMResponse, ProviderRequest

from .base.config_manager import ConfigManager
from .event_handler_modules import (
    GroupCapture,
    MemoryRecall,
    MemoryReflection,
    MessageUtils,
)
from .managers.conversation_manager import ConversationManager
from .managers.memory_engine import MemoryEngine
from .processors.memory_processor import MemoryProcessor
from .utils.injection_adapter import InjectionAdapter


class EventHandler:
    """事件处理器"""

    _SHUTDOWN_TIMEOUT_SECONDS = 10.0

    def __init__(
        self,
        context: Any,
        config_manager: ConfigManager,
        memory_engine: MemoryEngine,
        memory_processor: MemoryProcessor,
        conversation_manager: ConversationManager,
        consolidation_manager=None,
    ):
        """
        初始化事件处理器

        Args:
            context: AstrBot上下文
            config_manager: 配置管理器
            memory_engine: 记忆引擎
            memory_processor: 记忆处理器
            conversation_manager: 会话管理器
            consolidation_manager: 记忆整合管理器（用于反思触发）
        """
        self.context = context
        self.config_manager = config_manager
        self.memory_engine = memory_engine
        self.memory_processor = memory_processor
        self.conversation_manager = conversation_manager

        # 初始化子模块
        self._message_utils = MessageUtils(config_manager, conversation_manager)
        self._group_capture = GroupCapture(
            config_manager, conversation_manager, self._message_utils
        )
        # 后台存储任务跟踪
        self._storage_tasks: set[asyncio.Task] = set()
        self._storage_sessions_inflight: set[str] = set()
        self._storage_state_lock = asyncio.Lock()
        # 会话 -> 进行中的总结任务：回滚时按会话取消（召回模块也会用到）
        self._storage_session_tasks: dict[str, asyncio.Task] = {}
        self._shutting_down = False

        self._injection_adapter = InjectionAdapter()
        self._memory_recall = MemoryRecall(
            context,
            config_manager,
            memory_engine,
            conversation_manager,
            self._message_utils,
            self._injection_adapter,
            storage_session_tasks=self._storage_session_tasks,
        )

        self._memory_reflection = MemoryReflection(
            context,
            config_manager,
            memory_engine,
            memory_processor,
            conversation_manager,
            self._message_utils,
            self._storage_tasks,
            self._storage_sessions_inflight,
            self._storage_state_lock,
            consolidation_manager,
            storage_session_tasks=self._storage_session_tasks,
        )

    async def handle_all_group_messages(self, event: AstrMessageEvent):
        """Capture all group messages for memory storage"""
        await self._group_capture.handle_all_group_messages(event)

    async def handle_memory_recall(self, event: AstrMessageEvent, req: ProviderRequest):
        """Query and inject long-term memory before LLM request"""
        await self._memory_recall.handle_memory_recall(event, req)

    async def handle_memory_reflection(
        self, event: AstrMessageEvent, resp: LLMResponse
    ):
        """Check if reflection and memory storage is needed after LLM response"""
        await self._memory_reflection.handle_memory_reflection(event, resp)

    async def handle_session_reset(self, event: AstrMessageEvent) -> None:
        """处理 /reset 或 /new 触发的会话清空，同步清除插件侧的消息历史和总结计数器"""
        session_id = event.unified_msg_origin
        if not session_id:
            return
        try:
            await self.conversation_manager.clear_session(session_id)
            logger.info(f"[{session_id}] 已同步清空插件会话上下文（/reset 或 /new）")
        except Exception as e:
            logger.error(f"[{session_id}] 清空插件会话上下文失败: {e}", exc_info=True)

    async def shutdown(self):
        """关闭事件处理器，限时等待存储任务完成，超时则取消。"""
        self._shutting_down = True
        self._memory_reflection.set_shutting_down(True)
        pending = [task for task in self._storage_tasks if not task.done()]
        if pending:
            logger.info(f"等待 {len(pending)} 个存储任务完成（最多 10 秒）...")
            _, still_running = await asyncio.wait(
                pending, timeout=self._SHUTDOWN_TIMEOUT_SECONDS
            )
            for task in still_running:
                task.cancel()
            if still_running:
                await asyncio.gather(*still_running, return_exceptions=True)
                logger.warning(
                    f"已取消 {len(still_running)} 个未在超时内完成的存储任务"
                )
        self._storage_tasks.clear()
        self._storage_sessions_inflight.clear()
        self._storage_session_tasks.clear()
        logger.info("EventHandler 已关闭")
