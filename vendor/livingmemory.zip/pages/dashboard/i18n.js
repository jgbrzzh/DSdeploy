/* global localStorage, URLSearchParams, CustomEvent */

(() => {
  const LANG_KEY = "lmem_lang";
  const SUPPORTED = ["zh", "en", "ru", "ja"];
  let urlLanguageOverride = false;

  const MSG = {
    /* ---- Common ---- */
    "common.close":       { zh: "关闭", en: "Close", ru: "Закрыть" },
    "common.cancel":      { zh: "取消", en: "Cancel", ru: "Отмена" },
    "common.save":        { zh: "保存", en: "Save", ru: "Сохранить" },
    "common.refresh":     { zh: "刷新", en: "Refresh", ru: "Обновить" },
    "common.confirm":     { zh: "确定", en: "Confirm", ru: "Подтвердить" },
    "common.loading":     { zh: "加载中...", en: "Loading...", ru: "Загрузка..." },
    "common.retry":       { zh: "重试", en: "Retry", ru: "Повторить" },
    "table.openMemory":   { zh: "查看记忆 {0}", en: "Open memory {0}", ru: "Открыть память {0}" },
    "recall.searching":   { zh: "正在检索记忆…", en: "Searching memories…", ru: "Поиск воспоминаний…" },
    "common.noData":      { zh: "暂无数据", en: "No data", ru: "Нет данных" },
    "common.unavailable": { zh: "暂不可用", en: "Unavailable", ru: "Недоступно" },
    "common.page":        { zh: "第 {0} / {1} 页 · 共 {2} 条", en: "Page {0}/{1} · {2} total", ru: "Стр. {0}/{1} · всего {2}" },
    "common.perPage":     { zh: "每页", en: "Per page", ru: "На стр." },
    "common.perPage20":   { zh: "20 条/页", en: "20 per page", ru: "20 на стр." },
    "common.perPage50":   { zh: "50 条/页", en: "50 per page", ru: "50 на стр." },
    "common.perPage100":  { zh: "100 条/页", en: "100 per page", ru: "100 на стр." },
    "common.enabled":     { zh: "已启用", en: "Enabled", ru: "Включено" },
    "common.disabled":    { zh: "未启用", en: "Disabled", ru: "Отключено" },

    /* ---- Title / Header ---- */
    "page.title":         { zh: "LivingMemory 控制台", en: "LivingMemory Console", ru: "Консоль LivingMemory" },
    "header.lang":        { zh: "语言", en: "Language", ru: "Язык" },
    "language.toast":     { zh: "语言：{0}", en: "Language: {0}", ru: "Язык: {0}" },

    /* ---- Appearance ---- */
    "header.theme": {"zh": "外观与主题", "en": "Appearance", "ru": "Оформление"},
    "appearance.hint": {"zh": "选择即刻生效；偏好保存在当前浏览器。", "en": "Changes apply immediately and are saved in this browser.", "ru": "Изменения применяются сразу и сохраняются в этом браузере."},
    "appearance.style": {"zh": "视觉风格", "en": "Visual style", "ru": "Визуальный стиль"},
    "appearance.mode": {"zh": "明暗模式", "en": "Color mode", "ru": "Цветовой режим"},
    "appearance.system": {"zh": "自动", "en": "Auto", "ru": "Авто"},
    "appearance.light": {"zh": "浅色", "en": "Light", "ru": "Светлый"},
    "appearance.dark": {"zh": "深色", "en": "Dark", "ru": "Тёмный"},
    "appearance.systemHint": {"zh": "自动模式跟随 AstrBot；独立打开时跟随设备。", "en": "Auto follows AstrBot, or your device when opened independently.", "ru": "Авто следует теме AstrBot, а при отдельном открытии — теме устройства."},
    "appearance.editorial": {"zh": "Editorial · 原野", "en": "Editorial", "ru": "Editorial"},
    "appearance.editorialDesc": {"zh": "经典网格 · 醒目标题 · 利落线条", "en": "Classic grid, bold headlines, crisp lines", "ru": "Классическая сетка, крупные заголовки, чёткие линии"},
    "appearance.studio": {"zh": "Studio · 轻盈", "en": "Studio", "ru": "Studio"},
    "appearance.studioDesc": {"zh": "柔和圆角 · 蓝紫色调 · 悬浮卡片", "en": "Soft corners, indigo accents, floating cards", "ru": "Скругления, индиго, парящие карточки"},
    "appearance.paper": {"zh": "Paper · 书页", "en": "Paper", "ru": "Paper"},
    "appearance.paperDesc": {"zh": "暖纸色调 · 衬线标题 · 阅读留白", "en": "Warm paper, serif headings, room to read", "ru": "Тёплая бумага, заголовки с засечками, простор"},
    "appearance.terminal": {"zh": "Terminal · 终端", "en": "Terminal", "ru": "Terminal"},
    "appearance.terminalDesc": {"zh": "等宽字体 · 硬朗边框 · 仪表布局", "en": "Monospace type, sharp borders, instrument panels", "ru": "Моноширинный шрифт, строгие рамки, приборные панели"},

    /* ---- Workflow feedback ---- */
    "flow.resetFilters": {"zh": "重置筛选", "en": "Reset filters", "ru": "Сбросить фильтры"},
    "flow.status": {"zh": "状态", "en": "Status", "ru": "Статус"},
    "flow.type": {"zh": "类型", "en": "Type", "ru": "Тип"},
    "flow.sort": {"zh": "排序", "en": "Sort order", "ru": "Сортировка"},
    "flow.transfer": {"zh": "导入与导出", "en": "Import and export", "ru": "Импорт и экспорт"},
    "flow.exportAll": {"zh": "导出全部记忆，不受上方筛选条件限制。", "en": "Exports all memories, regardless of the filters above.", "ru": "Экспорт всех записей независимо от фильтров выше."},
    "flow.exportSelected": {"zh": "仅导出当前选中的 {0} 条记忆。", "en": "Exports only the {0} selected memories.", "ru": "Экспорт только выбранных записей: {0}."},
    "flow.importSteps": {"zh": "选择文件 → 检查预览 → 确认导入", "en": "Choose a file → Review preview → Confirm import", "ru": "Выберите файл → Проверьте → Подтвердите импорт"},
    "flow.selectedOnPage": {"zh": "本页已选 {0} 条", "en": "{0} selected on this page", "ru": "Выбрано на этой странице: {0}"},
    "flow.clearSelection": {"zh": "取消选择", "en": "Clear selection", "ru": "Снять выделение"},
    "flow.exporting": {"zh": "正在生成导出文件…", "en": "Preparing export…", "ru": "Подготовка экспорта…"},
    "flow.importReading": {"zh": "正在读取 {0}…", "en": "Reading {0}…", "ru": "Чтение {0}…"},
    "flow.importPreviewing": {"zh": "正在预检 {0}…", "en": "Validating {0}…", "ru": "Проверка {0}…"},
    "flow.importReview": {"zh": "请检查 {0} 的预览并确认导入。", "en": "Review the preview for {0} and confirm the import.", "ru": "Проверьте результат для {0} и подтвердите импорт."},
    "flow.importing": {"zh": "正在导入 {0}，请稍候…", "en": "Importing {0}, please wait…", "ru": "Импорт {0}, подождите…"},
    "flow.importCancelled": {"zh": "已取消导入，未写入记忆。", "en": "Import cancelled. No memories were written.", "ru": "Импорт отменён. Записи не добавлены."},
    "flow.nothingToImport": {"zh": "没有可导入的记忆：无效 {0} 条，重复 {1} 条。", "en": "Nothing to import: {0} invalid, {1} duplicates.", "ru": "Нечего импортировать: {0} некорректных, {1} дубликатов."},
    "flow.unsavedTitle": {"zh": "有未保存的修改", "en": "Unsaved changes", "ru": "Несохранённые изменения"},
    "flow.unsavedMessage": {"zh": "离开或替换内容会丢弃当前修改。是否放弃？", "en": "Leaving or replacing this content will discard your changes. Discard them?", "ru": "Выход или замена содержимого удалит ваши изменения. Отменить их?"},
    "flow.keepEditing": {"zh": "继续编辑", "en": "Keep editing", "ru": "Продолжить редактирование"},
    "flow.discard": {"zh": "放弃修改", "en": "Discard changes", "ru": "Отменить изменения"},
    "flow.waitForSave": {"zh": "正在处理，请完成后再离开。", "en": "An operation is in progress. Please wait before leaving.", "ru": "Операция выполняется. Дождитесь завершения перед выходом."},
    "flow.working": {"zh": "正在处理，请稍候…", "en": "Working, please wait…", "ru": "Выполняется, подождите…"},
    "flow.recallShortcut": {"zh": "快捷键：Ctrl / Cmd + Enter", "en": "Shortcut: Ctrl / Cmd + Enter", "ru": "Быстрый вызов: Ctrl / Cmd + Enter"},

    /* ---- Navigation ---- */
    "nav.memory":         { zh: "记忆管理", en: "Memory", ru: "Память" },
    "nav.graph":          { zh: "知识图谱", en: "Knowledge Graph", ru: "Граф знаний" },
    "nav.system":         { zh: "系统概览", en: "System", ru: "Система" },
    "nav.recall":         { zh: "召回测试", en: "Recall Test", ru: "Тест поиска" },
    "nav.prompts":        { zh: "提示词管理", en: "Prompts", ru: "Промпты" },
    "nav.settings":       { zh: "设置", en: "Settings", ru: "Настройки" },
    "settings.lead":      { zh: "高级配置", en: "Advanced settings", ru: "Расширенные настройки" },
    "settings.reloadHint": { zh: "高级配置集中在插件页面，保存后请重载插件使全部组件生效。", en: "Advanced settings live here instead of the AstrBot plugin config page. Reload the plugin after saving so every component picks them up.", ru: "Расширенные настройки находятся на этой странице; после сохранения перезагрузите плагин." },
    "settings.save":      { zh: "保存设置", en: "Save", ru: "Сохранить" },
    "settings.saved":     { zh: "配置已保存，请重载插件", en: "Saved — reload the plugin to apply everywhere", ru: "Сохранено — перезагрузите плагин" },
    "settings.saveFailed": { zh: "保存配置失败", en: "Failed to save settings", ru: "Не удалось сохранить настройки" },
    "settings.loading":   { zh: "正在加载配置…", en: "Loading settings…", ru: "Загрузка настроек…" },
    "settings.loadFailed": { zh: "加载配置失败", en: "Failed to load settings", ru: "Не удалось загрузить настройки" },
    "settings.empty":     { zh: "暂无可配置项", en: "No settings available", ru: "Нет доступных настроек" },
    "settings.invalidValue": { zh: "配置项 {0} 的值无效", en: "Invalid value for {0}", ru: "Недопустимое значение для {0}" },
    "settings.searchPlaceholder": { zh: "搜索配置项…", en: "Search settings…", ru: "Поиск настроек…" },
    "settings.expandAll": { zh: "展开全部", en: "Expand all", ru: "Развернуть всё" },
    "settings.collapseAll": { zh: "收起全部", en: "Collapse all", ru: "Свернуть всё" },
    "settings.fieldCount": { zh: "{0} 项", en: "{0} options", ru: "{0} параметров" },
    "settings.noMatches": { zh: "没有匹配的配置项", en: "No matching settings", ru: "Нет подходящих настроек" },
    "settings.recommended": { zh: "常用", en: "Common", ru: "Частые" },
    "settings.quickTitle": { zh: "常用设置", en: "Common settings", ru: "Частые настройки" },
    "settings.advancedTitle": { zh: "高级设置（按类别折叠）", en: "Advanced settings (grouped and collapsed)", ru: "Расширенные настройки (по категориям)" },
    "settings.catMemory": { zh: "记忆生成与生命周期", en: "Memory generation and lifecycle", ru: "Создание и жизненный цикл памяти" },
    "settings.catRecall": { zh: "召回与工具", en: "Recall and tools", ru: "Поиск и инструменты" },
    "settings.catGraph": { zh: "图谱与原子", en: "Graph and atoms", ru: "Граф и атомы" },
    "settings.catScope": { zh: "访问与隔离", en: "Access and isolation", ru: "Доступ и изоляция" },
    "settings.catSystem": { zh: "系统与维护", en: "System and maintenance", ru: "Система и обслуживание" },


    /* ---- Stats ---- */
    "stats.total":        { zh: "总记忆", en: "Total", ru: "Всего" },
    "stats.active":       { zh: "活跃", en: "Active", ru: "Активно" },
    "stats.archived":     { zh: "已归档", en: "Archived", ru: "Архив" },
    "stats.deleted":      { zh: "已删除", en: "Deleted", ru: "Удалено" },
    "stats.sessions":     { zh: "活跃会话", en: "Active Sessions", ru: "Активных сессий" },
    "stats.graphNodes":   { zh: "图谱节点", en: "Graph Nodes", ru: "Узлы графа" },
    "stats.atoms":        { zh: "原子记忆", en: "Atoms", ru: "Атомы" },

    /* ---- Filter ---- */
    "filter.keyword":     { zh: "关键字（支持 memory_id / 内容搜索）", en: "Keyword (memory_id / content)", ru: "Ключевое слово (memory_id / контент)" },
    "filter.sessionId":   { zh: "会话 ID（可选）", en: "Session ID (optional)", ru: "ID сессии (опц.)" },
    "filter.statusAll":   { zh: "全部状态", en: "All Statuses", ru: "Все статусы" },
    "filter.statusActive":{ zh: "活跃", en: "Active", ru: "Активно" },
    "filter.statusArchived":{ zh: "已归档", en: "Archived", ru: "Архив" },
    "filter.statusDeleted":{ zh: "已删除", en: "Deleted", ru: "Удалено" },
    "filter.typeAll":     { zh: "全部类型", en: "All Types", ru: "Все типы" },
    "filter.apply":       { zh: "筛选", en: "Filter", ru: "Фильтр" },

    /* ---- Sort ---- */
    "sort.createdDesc":   { zh: "最新创建", en: "Newest first", ru: "Сначала новые" },
    "sort.createdAsc":    { zh: "最早创建", en: "Oldest first", ru: "Сначала старые" },
    "sort.updatedDesc":   { zh: "最近更新", en: "Recently updated", ru: "Недавно обновлено" },
    "sort.importanceDesc":{ zh: "重要性高到低", en: "Importance high to low", ru: "Важность по убыванию" },
    "sort.importanceAsc": { zh: "重要性低到高", en: "Importance low to high", ru: "Важность по возрастанию" },
    "sort.typeAsc":       { zh: "类型 A-Z", en: "Type A-Z", ru: "Тип A-Z" },

    /* ---- Table ---- */
    "table.id":           { zh: "记忆 ID", en: "Memory ID", ru: "ID памяти" },
    "table.summary":      { zh: "摘要", en: "Summary", ru: "Сводка" },
    "table.type":         { zh: "类型", en: "Type", ru: "Тип" },
    "table.importance":   { zh: "重要性", en: "Importance", ru: "Важность" },
    "table.status":       { zh: "状态", en: "Status", ru: "Статус" },
    "table.created":      { zh: "创建时间", en: "Created", ru: "Создано" },
    "table.noData":       { zh: "暂无数据", en: "No data", ru: "Нет данных" },
    "table.updated":      { zh: "更新于 {0}", en: "Updated {0}", ru: "Обновлено {0}" },
    "table.consolidated": { zh: "整合 {0}", en: "Merged {0}", ru: "Объединено {0}" },
    "table.consolidatedTitle":{ zh: "由记忆整合合并产生", en: "Produced by memory consolidation", ru: "Создано консолидацией памяти" },

    /* ---- Pagination ---- */
    "pagination.prev":    { zh: "上一页", en: "Previous", ru: "Пред." },
    "pagination.next":    { zh: "下一页", en: "Next", ru: "След." },


    /* ---- Delete ---- */
    "delete.confirmTitle":{ zh: "确认删除？", en: "Confirm Delete?", ru: "Подтвердить удаление?" },
    "delete.confirmMsg":  { zh: "即将删除 {0} 条记忆。\n此操作无法撤销！\n\n点击\"确定\"继续删除，点击\"取消\"保留。", en: "About to delete {0} memories.\nThis cannot be undone!\n\nClick OK to proceed, Cancel to keep them.", ru: "Будет удалено {0} записей.\nЭто необратимо!\n\nНажмите ОК для удаления, Отмена для сохранения." },
    "delete.selected":    { zh: "删除所选 ({0})", en: "Delete selected ({0})", ru: "Удалить выбранные ({0})" },
    "delete.selectedTitle":{ zh: "删除当前页中选中的记忆", en: "Delete selected memories on this page", ru: "Удалить выбранные записи на этой странице" },
    "delete.selectAll":   { zh: "选择当前页全部记忆", en: "Select all memories on this page", ru: "Выбрать все записи на этой странице" },
    "delete.selectOne":   { zh: "选择记忆 #{0}", en: "Select memory #{0}", ru: "Выбрать память #{0}" },
    "delete.partialFailed":{ zh: "部分删除失败：成功 {0} 条，失败 {1} 条\n失败ID: {2}", en: "Partial failure: {0} succeeded, {1} failed\nFailed IDs: {2}", ru: "Частичная ошибка: {0} удалено, {1} не удалено\nID: {2}" },
    "delete.success":     { zh: " 已成功删除 {0} 条记忆", en: " Successfully deleted {0} memories", ru: " Удалено {0} записей" },
    "delete.error":       { zh: "删除失败，请稍后重试", en: "Delete failed, please try again later", ru: "Ошибка удаления, попробуйте позже" },

    "batchEdit.button":   { zh: "批量编辑 ({0})", en: "Batch edit ({0})", ru: "Массовое редактирование ({0})" },
    "batchEdit.title":    { zh: "批量编辑 {0} 条记忆", en: "Batch edit {0} memories", ru: "Массовое редактирование {0} записей" },
    "batchEdit.field":    { zh: "编辑字段", en: "Field to edit", ru: "Поле для изменения" },
    "batchEdit.importance":{ zh: "重要性", en: "Importance", ru: "Важность" },
    "batchEdit.status":   { zh: "状态", en: "Status", ru: "Статус" },
    "batchEdit.type":     { zh: "类型", en: "Type", ru: "Тип" },
    "batchEdit.value":    { zh: "新值", en: "New value", ru: "Новое значение" },
    "batchEdit.typePlaceholder":{ zh: "如 FACT / EVENT / PREFERENCE", en: "e.g. FACT / EVENT / PREFERENCE", ru: "напр. FACT / EVENT / PREFERENCE" },
    "batchEdit.apply":    { zh: "应用", en: "Apply", ru: "Применить" },
    "batchEdit.success":  { zh: "已成功更新 {0} 条记忆", en: "Successfully updated {0} memories", ru: "Обновлено {0} записей" },
    "batchEdit.partialFailed":{ zh: "部分更新失败：成功 {0} 条，失败 {1} 条", en: "Partial failure: {0} succeeded, {1} failed", ru: "Частичная ошибка: {0} обновлено, {1} не обновлено" },
    "batchEdit.error":    { zh: "批量编辑失败，请稍后重试", en: "Batch edit failed, please try again later", ru: "Ошибка массового редактирования, попробуйте позже" },
    "batchEdit.valueRequired":{ zh: "请输入新值", en: "Please enter a new value", ru: "Введите новое значение" },
    "batchEdit.importanceRange":{ zh: "重要性必须在 0-10 之间", en: "Importance must be between 0 and 10", ru: "Важность должна быть от 0 до 10" },

    /* ---- Import / Export ---- */
    "transfer.formatTitle":{ zh: "导出文件格式", en: "Export file format", ru: "Формат экспорта" },
    "transfer.duplicateTitle":{ zh: "导入重复项处理方式", en: "Duplicate handling during import", ru: "Обработка дубликатов при импорте" },
    "transfer.skipDuplicates":{ zh: "跳过重复", en: "Skip duplicates", ru: "Пропускать дубликаты" },
    "transfer.allowDuplicates":{ zh: "允许重复", en: "Allow duplicates", ru: "Разрешить дубликаты" },
    "transfer.export":    { zh: "导出", en: "Export", ru: "Экспорт" },
    "transfer.import":    { zh: "导入", en: "Import", ru: "Импорт" },
    "transfer.exportTitle":{ zh: "有选中项时导出所选，否则导出全部", en: "Export selected memories, or all when none are selected", ru: "Экспортировать выбранные или все записи" },
    "transfer.importTitle":{ zh: "导入 JSON 或 CSV 记忆文件", en: "Import a JSON or CSV memory file", ru: "Импорт файла памяти JSON или CSV" },
    "transfer.exportSuccess":{ zh: "已导出 {0} 条记忆", en: "Exported {0} memories", ru: "Экспортировано записей: {0}" },
    "transfer.importPreviewTitle":{ zh: "确认导入记忆", en: "Confirm Memory Import", ru: "Подтвердить импорт памяти" },
    "transfer.importPreview":{ zh: "有效 {0} 条，计划导入 {1} 条，重复 {2} 条，无效 {3} 条，需要 LLM 总结 {4} 条。", en: "Valid: {0}; planned: {1}; duplicates: {2}; invalid: {3}; requiring LLM summaries: {4}.", ru: "Корректно: {0}; к импорту: {1}; дубликаты: {2}; ошибки: {3}; требуют LLM: {4}." },
    "transfer.importSuccess":{ zh: "已导入 {0} 条，跳过重复 {1} 条，失败 {2} 条", en: "Imported {0}; skipped {1} duplicates; failed {2}", ru: "Импортировано: {0}; пропущено дубликатов: {1}; ошибок: {2}" },
    "transfer.fileTooLarge":{ zh: "导入文件不能超过 50 MiB", en: "Import file must not exceed 50 MiB", ru: "Файл импорта не должен превышать 50 MiB" },
    "transfer.failed":    { zh: "记忆导入或导出失败", en: "Memory import or export failed", ru: "Ошибка импорта или экспорта памяти" },


    /* ---- Detail Drawer ---- */
    "detail.edit":        { zh: "编辑记忆", en: "Edit Memory", ru: "Редактировать" },
    "detail.source":      { zh: "来源", en: "Source", ru: "Источник" },
    "detail.status":      { zh: "状态", en: "Status", ru: "Статус" },
    "detail.importance":  { zh: "重要性", en: "Importance", ru: "Важность" },
    "detail.type":        { zh: "类型", en: "Type", ru: "Тип" },
    "detail.created":     { zh: "创建时间", en: "Created", ru: "Создано" },

    /* ---- Edit Modal ---- */
    "edit.field":         { zh: "编辑字段", en: "Edit Field", ru: "Поле" },
    "edit.updateFailed":  { zh: "更新失败", en: "Update failed", ru: "Ошибка обновления" },

    /* ---- Status pills ---- */
    "status.active":      { zh: "活跃", en: "Active", ru: "Активно" },
    "status.archived":    { zh: "已归档", en: "Archived", ru: "Архив" },
    "status.deleted":     { zh: "已删除", en: "Deleted", ru: "Удалено" },

    /* ---- Type labels ---- */
    "type.general":       { zh: "通用", en: "General", ru: "Общее" },
    "type.fact":          { zh: "事实", en: "Fact", ru: "Факт" },
    "type.factual":       { zh: "事实", en: "Factual", ru: "Факт" },
    "type.preference":    { zh: "偏好", en: "Preference", ru: "Предпочтение" },
    "type.event":         { zh: "事件", en: "Event", ru: "Событие" },
    "type.episodic":      { zh: "事件", en: "Episodic", ru: "Эпизод" },
    "type.relational":    { zh: "关系", en: "Relational", ru: "Связь" },
    "type.planned":       { zh: "计划", en: "Planned", ru: "План" },
    "type.opinion":       { zh: "观点", en: "Opinion", ru: "Мнение" },


    /* ---- Graph Toolbar ---- */
    "graph.queryPh":      { zh: "输入人物、主题、事实或整句，查看召回到的图谱子图", en: "Enter a person, topic, fact or sentence to view the recalled subgraph", ru: "Введите персону, тему, факт или фразу для просмотра подграфа" },
    "graph.sessionPh":    { zh: "可选：限定 session_id", en: "Optional: limit to session_id", ru: "Опц.: ограничить session_id" },
    "graph.searchBtn":    { zh: "检索图谱", en: "Search Graph", ru: "Искать в графе" },
    "graph.focusOnGraph": { zh: "在图谱中定位", en: "Locate in graph", ru: "Показать на графе" },
    "graph.overviewBtn":  { zh: "全量图谱", en: "Full Graph", ru: "Весь граф" },
    "graph.limitedBtn":   { zh: "受限概览", en: "Limited View", ru: "Ограниченный обзор" },

    /* ---- Graph Stats ---- */
    "graph.nodes":        { zh: "节点", en: "Nodes", ru: "Узлы" },
    "graph.edges":        { zh: "关系", en: "Relations", ru: "Связи" },



    /* ---- Graph Node Types ---- */
    "graph.nodeTopic":    { zh: "主题", en: "Topic", ru: "Тема" },
    "graph.nodePerson":   { zh: "人物", en: "Person", ru: "Человек" },
    "graph.nodeFact":     { zh: "事实", en: "Fact", ru: "Факт" },
    "graph.nodeSummary":  { zh: "摘要", en: "Summary", ru: "Сводка" },
    "graph.nodeUnknown":  { zh: "节点", en: "Node", ru: "Узел" },

    /* ---- Graph Score Labels ---- */
    "graph.scoreDocKW":   { zh: "文档关键词", en: "Doc Keyword", ru: "Ключ. слова док." },
    "graph.scoreDocVec":  { zh: "文档向量", en: "Doc Vector", ru: "Вектор док." },
    "graph.scoreGraphKW": { zh: "图关键词", en: "Graph Keyword", ru: "Ключ. слова графа" },
    "graph.scoreGraphVec":{ zh: "图向量", en: "Graph Vector", ru: "Вектор графа" },

    /* ---- Graph Disabled ---- */
    "graph.disabledMsg":  { zh: "当前实例未启用图记忆功能，请先开启图记忆并完成索引。", en: "Graph memory is not enabled. Enable it and complete indexing first.", ru: "Граф памяти не включён. Включите его и завершите индексацию." },

    /* ---- Graph Error ---- */
    "graph.errorFetch":   { zh: "无法加载图谱概览", en: "Cannot load graph overview", ru: "Не удалось загрузить обзор графа" },

    /* ---- Graph Canvas Messages ---- */
    "graph.canvasEmpty":  { zh: "当前范围内暂无可视化图数据。", en: "No visible graph data in the current range.", ru: "Нет видимых данных графа в текущем диапазоне." },

    /* ---- Graph Loading ---- */
    "graph.loadingOverview":{ zh: "正在加载图谱概览...", en: "Loading graph overview...", ru: "Загрузка обзора графа..." },
    "graph.layouting":    { zh: "正在生成图谱布局...", en: "Preparing graph layout...", ru: "Подготовка макета графа..." },
    "graph.loadingQuery": { zh: "正在检索\"{0}\"相关图谱...", en: "Retrieving graph for \"{0}\"...", ru: "Поиск графа для \"{0}\"..." },
    "graph.loadingFocus": { zh: "正在聚焦记忆 #{0} 的关系图...", en: "Focusing on relation graph of memory #{0}...", ru: "Фокус на графе связей памяти #{0}..." },

    /* ---- Graph Errors (actions) ---- */
    "graph.queryFail":    { zh: "图谱检索失败", en: "Graph retrieval failed", ru: "Ошибка поиска в графе" },
    "graph.focusFail":    { zh: "定位记忆失败", en: "Memory focus failed", ru: "Ошибка фокуса памяти" },

    /* ---- Graph Legend ---- */
    "graph.legendEmpty":  { zh: "暂无图谱连接", en: "No graph connections", ru: "Нет соединений в графе" },
    "graph.visibleNodes": { zh: "节点 {0} / {1}", en: "Nodes {0} / {1}", ru: "Узлы {0} / {1}" },
    "graph.nodeMeta":     { zh: "{0} 条记忆 · {1} 条连接", en: "{0} memories · {1} links", ru: "{0} памятей · {1} связей" },

    /* ---- Graph Panels Content ---- */
    "graph.unnamedNode":  { zh: "未命名节点", en: "Unnamed Node", ru: "Безымянный узел" },



    /* ---- Graph Bridge Error ---- */
    "graph.bridgeError":  { zh: "当前页面必须运行在 AstrBot 官方插件视图内。", en: "This page must run inside an AstrBot plugin view.", ru: "Страница должна работать внутри представления плагина AstrBot." },

    /* ---- Recall Test ---- */
    "recall.queryPh":     { zh: "输入查询语句测试召回效果", en: "Enter a query to test recall", ru: "Введите запрос для проверки поиска" },
    "recall.kLabel":      { zh: "结果数 (k)", en: "Results (k)", ru: "Результаты (k)" },
    "recall.sessionLabel":{ zh: "会话 ID (可选)", en: "Session ID (optional)", ru: "ID сессии (опц.)" },
    "recall.sessionPh":   { zh: "输入会话 ID 以过滤特定会话的记忆（支持多种格式）", en: "Enter session ID to filter memories (supports multiple formats)", ru: "Введите ID сессии для фильтрации (разные форматы)" },
    "recall.searchBtn":   { zh: "执行召回", en: "Run Recall", ru: "Запустить поиск" },
    "recall.resultsCount":{ zh: "{0} 条结果", en: "{0} results", ru: "{0} результатов" },
    "recall.time":        { zh: "查询耗时", en: "Query Time", ru: "Время запроса" },
    "recall.empty":       { zh: "暂无召回结果 · 请输入查询内容并执行召回", en: "No results · Enter a query and run recall", ru: "Нет результатов · Введите запрос и запустите поиск" },
    "recall.noMatch":     { zh: "未找到匹配的记忆", en: "No matching memories found", ru: "Совпадений не найдено" },
    "recall.enterQuery":  { zh: "请输入查询内容", en: "Please enter a query", ru: "Введите запрос" },
    "recall.fail":        { zh: "召回失败", en: "Recall failed", ru: "Ошибка поиска" },
    "recall.timeElapsed": { zh: "耗时 {0} 秒", en: "{0}s elapsed", ru: "Затрачено {0} с" },

    /* ---- Recall Results Metadata ---- */
    "recall.resultId":    { zh: "记忆 ID:", en: "Memory ID:", ru: "ID памяти:" },
    "recall.resultScore": { zh: "综合得分:", en: "Final score:", ru: "Итоговая оценка:" },


    /* ---- Bridge Error ---- */
    "bridge.error":       { zh: "当前页面必须运行在 AstrBot 官方插件视图内", en: "This page must run inside an AstrBot plugin view", ru: "Страница должна работать внутри представления плагина AstrBot" },

    /* ---- Misc ---- */
    "misc.requestFailed": { zh: "请求失败", en: "Request failed", ru: "Ошибка запроса" },
    "misc.statsFail":     { zh: "获取统计信息失败", en: "Failed to fetch stats", ru: "Не удалось получить статистику" },
    "misc.fetchMemoriesFail":{ zh: "获取记忆失败", en: "Failed to fetch memories", ru: "Не удалось загрузить память" },

    /* ---- System ---- */
    "system.importanceDistribution":{ zh: "重要性分布", en: "Importance Distribution", ru: "Распределение важности" },
    "system.atomTypes":   { zh: "原子类型", en: "Atom Types", ru: "Типы атомов" },
    "system.sessionsTitle":{ zh: "会话（按记忆条数）", en: "Sessions (by memory count)", ru: "Сессии (по числу памятей)" },
    "system.versionBackups":{ zh: "版本备份", en: "Version Backups", ru: "Резервные копии" },
    "system.noSessions":  { zh: "暂无会话", en: "No sessions", ru: "Нет сессий" },
    "system.noBackups":   { zh: "暂无备份", en: "No backups", ru: "Нет резервных копий" },
    "system.noAtoms":     { zh: "暂无原子数据", en: "No atom data", ru: "Нет данных атомов" },
    "system.files":       { zh: "个文件", en: "files", ru: "файлов" },
    "system.memories":    { zh: "条记忆", en: "memories", ru: "памятей" },
    "system.fetchFailed": { zh: "获取系统数据失败", en: "Failed to fetch system data", ru: "Не удалось получить данные системы" },
    "system.atomFactual": { zh: "事实", en: "Factual", ru: "Фактическая" },
    "system.atomEpisodic":{ zh: "事件", en: "Episodic", ru: "Эпизодическая" },
    "system.atomRelational":{ zh: "关系", en: "Relational", ru: "Связи" },
    "system.atomPlanned": { zh: "计划", en: "Planned", ru: "Планы" },
    "system.consolidationTitle":{ zh: "记忆整合", en: "Memory Consolidation", ru: "Консолидация памяти" },
    "system.consolidatedCount":{ zh: "已整合", en: "Consolidated", ru: "Консолидировано" },
    "system.consolidationRun":{ zh: "立即整合", en: "Run Now", ru: "Запустить" },
    "system.consStatus":  { zh: "状态", en: "Status", ru: "Статус" },
    "system.consTrigger": { zh: "触发", en: "Trigger", ru: "Запуск" },
    "system.consTriggerDaily":{ zh: "每日", en: "Daily", ru: "Ежедневно" },
    "system.consTriggerReflection":{ zh: "反思时", en: "On reflection", ru: "При рефлексии" },
    "system.consGranularity":{ zh: "粒度", en: "Granularity", ru: "Гранулярность" },
    "system.consGranularitySession":{ zh: "同会话", en: "Same session", ru: "По сессии" },
    "system.consGranularitySemantic":{ zh: "语义聚类", en: "Semantic", ru: "Семантическая" },
    "system.consKeep":    { zh: "旧记忆", en: "Originals", ru: "Исходные" },
    "system.consKeepArchive":{ zh: "归档", en: "Archive", ru: "Архивировать" },
    "system.consKeepDelete":{ zh: "删除", en: "Delete", ru: "Удалить" },
    "system.consRunning": { zh: "整合中...", en: "Consolidating...", ru: "Консолидация..." },
    "system.consSkipped": { zh: "已跳过（未启用或冷却中）", en: "Skipped (disabled or cooling down)", ru: "Пропущено (отключено или охлаждение)" },
    "system.consResult":  { zh: "整合完成：{0} 组、合并 {1} 条、归档 {2}、删除 {3}、失败 {4}", en: "Done: {0} groups, {1} merged, {2} archived, {3} deleted, {4} failed", ru: "Готово: групп {0}, объединено {1}, архив {2}, удалено {3}, ошибок {4}" },
    "system.consNoCandidates":{ zh: "没有可整合的候选", en: "No candidates to consolidate", ru: "Нет кандидатов для объединения" },

    /* ---- Atom labels ---- */
    "atom.entity":        { zh: "实体", en: "Entity", ru: "Сущность" },
    "atom.event":         { zh: "事件", en: "Event", ru: "Событие" },
    "atom.preference":    { zh: "偏好", en: "Preference", ru: "Предпочтение" },
    "atom.topic":         { zh: "主题", en: "Topic", ru: "Тема" },

    /* ---- Memory Detail ---- */
    "detail.content":     { zh: "内容", en: "Content", ru: "Содержимое" },
    "detail.metadata":    { zh: "元数据", en: "Metadata", ru: "Метаданные" },
    "detail.graphContext":{ zh: "知识图谱关联", en: "Knowledge Graph Context", ru: "Контекст графа знаний" },
    "detail.keyFacts":    { zh: "关键事实", en: "Key Facts", ru: "Ключевые факты" },
    "detail.topics":      { zh: "主题", en: "Topics", ru: "Темы" },
    "detail.editHistory": { zh: "编辑历史", en: "Edit History", ru: "История изменений" },
    "detail.editBtn":     { zh: "编辑", en: "Edit", ru: "Редактировать" },
    "detail.resummarizeBtn":{ zh: "重新总结", en: "Re-summarize", ru: "Пересуммировать" },
    "detail.sourceMessages":{ zh: "原始消息（{0} 条）", en: "Source messages ({0})", ru: "Исходные сообщения ({0})" },
    "detail.consolidatedFrom":{ zh: "来源记忆（整合自 {0} 条）", en: "Consolidated from {0} memories", ru: "Объединено из {0} памятей" },
    "detail.resummarizeSuccess":{ zh: "已重新总结（新 ID：{0}）", en: "Re-summarized (new ID: {0})", ru: "Пересуммировано (новый ID: {0})" },
    "detail.resummarizeFailed":{ zh: "重新总结失败", en: "Failed to re-summarize", ru: "Не удалось пересуммировать" },
    "detail.deleteBtn":   { zh: "删除", en: "Delete", ru: "Удалить" },
    "detail.saveBtn":     { zh: "保存修改", en: "Save Changes", ru: "Сохранить" },
    "detail.cancelBtn":   { zh: "取消", en: "Cancel", ru: "Отмена" },
    "detail.memoryTitle": { zh: "记忆 #{0}", en: "Memory #{0}", ru: "Память #{0}" },
    "detail.sessionId":   { zh: "会话 ID", en: "Session ID", ru: "ID сессии" },
    "detail.personaId":   { zh: "人格 ID", en: "Persona ID", ru: "ID персоны" },
    "origin.agent":       { zh: "Agent 写入", en: "Agent", ru: "Агент" },
    "origin.import":      { zh: "导入", en: "Imported", ru: "Импорт" },
    "origin.resummarize": { zh: "重新总结", en: "Re-summarized", ru: "Пересводка" },
    "origin.auto":        { zh: "自动总结", en: "Auto", ru: "Авто" },
    "detail.memorizeReason":{ zh: "记忆原因", en: "Why remembered", ru: "Причина запоминания" },
    "detail.previousId":  { zh: "原记忆 ID", en: "Previous ID", ru: "Предыдущий ID" },
    "detail.botMessage":  { zh: "机器人", en: "Bot", ru: "Бот" },
    "detail.qualityLow":  { zh: "摘要质量偏低", en: "Low summary quality", ru: "Низкое качество сводки" },
    "detail.loadFailed":  { zh: "详情加载失败，显示本地缓存", en: "Failed to load details; showing cached data", ru: "Не удалось загрузить детали; показаны кэшированные данные" },
    "detail.updated":     { zh: "更新时间", en: "Updated", ru: "Обновлено" },
    "detail.updateReason":{ zh: "更新原因（可选）", en: "Update Reason (optional)", ru: "Причина обновления (опц.)" },
    "detail.reasonPh":    { zh: "说明本次更新的原因", en: "Why this update?", ru: "Причина обновления" },
    "detail.contentHint": { zh: "编辑内容、主题或关键事实将创建新记忆（ID会变更）", en: "Editing content, topics, or key facts creates a new memory (ID will change).", ru: "Изменение содержимого, тем или ключевых фактов создаст новую память (ID изменится)." },
    "detail.noChanges":   { zh: "没有检测到修改", en: "No changes", ru: "Нет изменений" },
    "detail.contentRequired":{ zh: "记忆内容不能为空", en: "Memory content cannot be empty", ru: "Содержимое памяти не может быть пустым" },
    "detail.contentUpdated":{ zh: "内容已更新（新 ID：{0}）", en: "Content updated (new ID: {0})", ru: "Содержимое обновлено (новый ID: {0})" },
    "detail.topicsUpdated":{ zh: "主题已更新", en: "Topics updated", ru: "Темы обновлены" },
    "detail.keyFactsUpdated":{ zh: "关键事实已更新", en: "Key facts updated", ru: "Ключевые факты обновлены" },
    "detail.statusUpdated":{ zh: "状态 → {0}", en: "Status → {0}", ru: "Статус → {0}" },
    "detail.typeUpdated": { zh: "类型 → {0}", en: "Type → {0}", ru: "Тип → {0}" },
    "detail.importanceUpdated":{ zh: "重要性 → {0}", en: "Importance → {0}", ru: "Важность → {0}" },
    "detail.nodeMemories":{ zh: "关联记忆", en: "Memories", ru: "Память" },
    "detail.nodeDegree":  { zh: "连接度", en: "Degree", ru: "Степень" },
    "detail.nodeEntries": { zh: "条目", en: "Entries", ru: "Записи" },
    "detail.nodeWeight":  { zh: "权重", en: "Weight", ru: "Вес" },

    /* ---- Confirm dialog ---- */
    "confirm.deleteTitle":{ zh: "确认删除？", en: "Confirm delete?", ru: "Подтвердить удаление?" },
    "confirm.deleteMessage":{ zh: "即将删除记忆 #{0}。此操作无法撤销。", en: "Memory #{0} will be deleted. This cannot be undone.", ru: "Память #{0} будет удалена. Это необратимо." },
    "memory.deleted":     { zh: "记忆已删除", en: "Memory deleted", ru: "Память удалена" },
    "memory.deleteFailed":{ zh: "删除记忆失败", en: "Failed to delete memory", ru: "Не удалось удалить память" },

    /* ---- Graph 2D ---- */
    "graph2d.moduleFail": { zh: "2D 图谱模块未加载，请刷新页面重试。", en: "2D graph module not loaded. Refresh and retry.", ru: "2D модуль графа не загружен. Обновите страницу." },

    /* ---- Prompt Management ---- */
    "prompt.fetchFailed":   { zh: "加载提示词列表失败", en: "Failed to load prompts", ru: "Не удалось загрузить промпты" },
    "prompt.noPrompts":     { zh: "暂无提示词数据", en: "No prompt data", ru: "Нет данных промптов" },
    "prompt.customized":    { zh: "已自定义", en: "Customized", ru: "Изменён" },
    "prompt.variables":     { zh: "可用变量", en: "Variables", ru: "Переменные" },
    "prompt.edit":          { zh: "编辑", en: "Edit", ru: "Редактировать" },
    "prompt.customizedStatus": { zh: "（已自定义）", en: "(Customized)", ru: "(Изменён)" },
    "prompt.defaultStatus": { zh: "（使用默认）", en: "(Default)", ru: "(По умолчанию)" },
    "prompt.saved":         { zh: "提示词已保存", en: "Prompt saved", ru: "Промпт сохранён" },
    "prompt.saveFailed":    { zh: "保存提示词失败", en: "Failed to save prompt", ru: "Не удалось сохранить промпт" },
    "prompt.loadFailed":    { zh: "加载提示词详情失败", en: "Failed to load prompt detail", ru: "Не удалось загрузить промпт" },
    "prompt.reset":         { zh: "载入默认内容", en: "Load default content", ru: "Загрузить по умолчанию" },
    "prompt.resetDone":     { zh: "已恢复为默认值", en: "Reset to default", ru: "Сброшено" },
    "prompt.resetFailed":   { zh: "恢复默认失败", en: "Failed to reset prompt", ru: "Не удалось сбросить промпт" },
    "prompt.defaultFilled": { zh: "已填充默认内容，请点击保存以确认", en: "Default content loaded. Click Save to confirm.", ru: "Содержимое по умолчанию загружено. Нажмите Сохранить." },
    "prompt.defaultFilledStatus": { zh: "（待保存：默认内容）", en: "(Pending: default content)", ru: "(Ожидает: по умолчанию)" },
    "prompt.jsonRequired": { zh: "此模板必须要求 LLM 输出 JSON 格式，修改可能导致记忆功能失效", en: "This template MUST require JSON output from the LLM. Modifying may break memory.", ru: "Этот шаблон ДОЛЖЕН требовать вывод JSON от LLM." },
  };

  /* Japanese translations, merged into MSG so every entry keeps one shape. */
  const MSG_JA = {
    "appearance.dark": "ダーク",
    "appearance.editorial": "Editorial · 原野",
    "appearance.editorialDesc": "クラシックなグリッド · 力強い見出し · シャープなライン",
    "appearance.hint": "変更はすぐに反映され、設定はこのブラウザに保存されます。",
    "appearance.light": "ライト",
    "appearance.mode": "カラーモード",
    "appearance.paper": "Paper · ページ",
    "appearance.paperDesc": "暖かな紙色 · セリフ見出し · 読書余白",
    "appearance.studio": "Studio · 軽やか",
    "appearance.studioDesc": "柔らかな角丸 · 藍紫系 · フローティングカード",
    "appearance.style": "ビジュアルスタイル",
    "appearance.system": "自動",
    "appearance.systemHint": "自動は AstrBot に従い、単独で開いた場合は端末に従います。",
    "appearance.terminal": "Terminal · 端末",
    "appearance.terminalDesc": "等幅フォント · 硬質な枠線 · ダッシュボード配置",
    "atom.entity": "エンティティ",
    "atom.event": "出来事",
    "atom.preference": "好み",
    "atom.topic": "テーマ",
    "batchEdit.apply": "適用",
    "batchEdit.button": "一括編集 ({0})",
    "batchEdit.error": "一括編集に失敗しました。後ほど再試行してください",
    "batchEdit.field": "編集フィールド",
    "batchEdit.importance": "重要度",
    "batchEdit.importanceRange": "重要度は 0〜10 の範囲で指定してください",
    "batchEdit.partialFailed": "一部更新に失敗しました：成功 {0} 件、失敗 {1} 件",
    "batchEdit.status": "ステータス",
    "batchEdit.success": "{0} 件の記憶を更新しました",
    "batchEdit.title": "{0} 件の記憶を一括編集",
    "batchEdit.type": "種類",
    "batchEdit.typePlaceholder": "例: FACT / EVENT / PREFERENCE",
    "batchEdit.value": "新しい値",
    "batchEdit.valueRequired": "新しい値を入力してください",
    "bridge.error": "このページは AstrBot 公式プラグイン View 内で実行する必要があります",
    "common.cancel": "キャンセル",
    "common.close": "閉じる",
    "common.confirm": "確認",
    "common.disabled": "無効",
    "common.enabled": "有効",
    "common.loading": "読み込み中...",
    "common.noData": "データなし",
    "common.page": "ページ {0} / {1} · 全 {2} 件",
    "common.perPage": "ページごと",
    "common.perPage100": "100 件/ページ",
    "common.perPage20": "20 件/ページ",
    "common.perPage50": "50 件/ページ",
    "common.refresh": "更新",
    "common.retry": "再試行",
    "common.save": "保存",
    "common.unavailable": "利用不可",
    "confirm.deleteMessage": "記憶 #{0} を削除します。この操作は元に戻せません。",
    "confirm.deleteTitle": "削除してよろしいですか？",
    "delete.confirmMsg": "{0} 件の記憶を削除します。\nこの操作は元に戻せません！\n\n「確認」で削除を続け、「キャンセル」で保持します。",
    "delete.confirmTitle": "削除してよろしいですか？",
    "delete.error": "削除に失敗しました。後ほど再試行してください",
    "delete.partialFailed": "一部削除に失敗しました：成功 {0} 件、失敗 {1} 件\n失敗ID: {2}",
    "delete.selectAll": "現在のページのすべての記憶を選択",
    "delete.selectOne": "記憶 #{0} を選択",
    "delete.selected": "選択を削除 ({0})",
    "delete.selectedTitle": "現在のページで選択した記憶を削除",
    "delete.success": " 記憶 {0} 件を削除しました",
    "detail.botMessage": "ボット",
    "detail.cancelBtn": "キャンセル",
    "detail.consolidatedFrom": "ソース記憶（{0} 件から統合）",
    "detail.content": "内容",
    "detail.contentHint": "内容・テーマ・主要な事実を編集すると新しい記憶が作成されます（ID が変わります）",
    "detail.contentRequired": "記憶内容は空にできません",
    "detail.contentUpdated": "内容を更新しました（新 ID：{0}）",
    "detail.created": "作成日時",
    "detail.deleteBtn": "削除",
    "detail.edit": "記憶を編集",
    "detail.editBtn": "編集",
    "detail.editHistory": "編集履歴",
    "detail.graphContext": "ナレッジグラフ関連",
    "detail.importance": "重要度",
    "detail.importanceUpdated": "重要度 → {0}",
    "detail.keyFacts": "主要な事実",
    "detail.keyFactsUpdated": "主要な事実を更新しました",
    "detail.loadFailed": "詳細の読み込みに失敗しました。ローカルキャッシュを表示しています",
    "detail.memorizeReason": "記憶理由",
    "detail.memoryTitle": "記憶 #{0}",
    "detail.metadata": "メタデータ",
    "detail.noChanges": "変更が検出されませんでした",
    "detail.nodeDegree": "接続度",
    "detail.nodeEntries": "エントリ",
    "detail.nodeMemories": "関連記憶",
    "detail.nodeWeight": "重み",
    "detail.personaId": "ペルソナ ID",
    "detail.previousId": "元の記憶 ID",
    "detail.qualityLow": "要約品質が低い",
    "detail.reasonPh": "今回の更新理由を記載",
    "detail.resummarizeBtn": "再要約",
    "detail.resummarizeFailed": "再要約に失敗しました",
    "detail.resummarizeSuccess": "再要約しました（新 ID：{0}）",
    "detail.saveBtn": "変更を保存",
    "detail.sessionId": "セッション ID",
    "detail.source": "ソース",
    "detail.sourceMessages": "元のメッセージ（{0} 件）",
    "detail.status": "ステータス",
    "detail.statusUpdated": "ステータス → {0}",
    "detail.topics": "テーマ",
    "detail.topicsUpdated": "テーマを更新しました",
    "detail.type": "種類",
    "detail.typeUpdated": "種類 → {0}",
    "detail.updateReason": "更新理由（任意）",
    "detail.updated": "更新日時",
    "edit.field": "編集フィールド",
    "edit.updateFailed": "更新に失敗しました",
    "filter.apply": "絞り込み",
    "filter.keyword": "キーワード（memory_id / 内容検索に対応）",
    "filter.sessionId": "セッション ID（任意）",
    "filter.statusActive": "アクティブ",
    "filter.statusAll": "すべてのステータス",
    "filter.statusArchived": "アーカイブ済み",
    "filter.statusDeleted": "削除済み",
    "filter.typeAll": "すべての種類",
    "flow.clearSelection": "選択を解除",
    "flow.discard": "変更を破棄",
    "flow.exportAll": "すべての記憶をエクスポートします（上のフィルタ条件は適用されません）。",
    "flow.exportSelected": "選択中の {0} 件の記憶のみをエクスポートします。",
    "flow.exporting": "エクスポートファイルを生成中…",
    "flow.importCancelled": "インポートをキャンセルしました。記憶は書き込まれていません。",
    "flow.importPreviewing": "{0} を事前確認中…",
    "flow.importReading": "{0} を読み込み中…",
    "flow.importReview": "{0} のプレビューを確認してインポートを確定してください。",
    "flow.importSteps": "ファイル選択 → プレビュー確認 → インポート確定",
    "flow.importing": "{0} をインポート中です。しばらくお待ちください…",
    "flow.keepEditing": "編集を続ける",
    "flow.nothingToImport": "インポートできる記憶がありません：無効 {0} 件、重複 {1} 件。",
    "flow.recallShortcut": "ショートカット：Ctrl / Cmd + Enter",
    "flow.resetFilters": "フィルタをリセット",
    "flow.selectedOnPage": "このページで {0} 件選択中",
    "flow.sort": "並び順",
    "flow.status": "ステータス",
    "flow.transfer": "インポートとエクスポート",
    "flow.type": "種類",
    "flow.unsavedMessage": "移動または内容の置換により現在の変更が失われます。破棄しますか？",
    "flow.unsavedTitle": "未保存の変更があります",
    "flow.waitForSave": "処理中です。完了してから移動してください。",
    "flow.working": "処理中です。しばらくお待ちください…",
    "graph.bridgeError": "このページは AstrBot 公式プラグイン View 内で実行する必要があります。",
    "graph.canvasEmpty": "現在の範囲に表示可能なグラフデータがありません。",
    "graph.disabledMsg": "このインスタンスではグラフ記憶が無効です。グラフ記憶を有効にしてインデックスを完了してください。",
    "graph.edges": "関係",
    "graph.errorFetch": "グラフ概要を読み込めません",
    "graph.focusFail": "記憶の特定に失敗しました",
    "graph.focusOnGraph": "グラフ内で特定",
    "graph.layouting": "グラフレイアウトを生成中...",
    "graph.legendEmpty": "グラフ接続なし",
    "graph.limitedBtn": "制限付き概要",
    "graph.loadingFocus": "記憶 #{0} の関係グラフにフォーカス中...",
    "graph.loadingOverview": "グラフ概要を読み込み中...",
    "graph.loadingQuery": "「{0}」に関連するグラフを検索中...",
    "graph.nodeFact": "事実",
    "graph.nodeMeta": "{0} 件の記憶 · {1} 件の接続",
    "graph.nodePerson": "人物",
    "graph.nodeSummary": "要約",
    "graph.nodeTopic": "テーマ",
    "graph.nodeUnknown": "ノード",
    "graph.nodes": "ノード",
    "graph.overviewBtn": "全量グラフ",
    "graph.queryFail": "グラフ検索に失敗しました",
    "graph.queryPh": "人物、テーマ、事実、または文章を入力して、検索されたグラフ部分を表示",
    "graph.scoreDocKW": "文書キーワード",
    "graph.scoreDocVec": "文書ベクトル",
    "graph.scoreGraphKW": "グラフキーワード",
    "graph.scoreGraphVec": "グラフベクトル",
    "graph.searchBtn": "グラフを検索",
    "graph.sessionPh": "任意：session_id を指定",
    "graph.unnamedNode": "名前なしノード",
    "graph.visibleNodes": "ノード {0} / {1}",
    "graph2d.moduleFail": "2D グラフモジュールが読み込まれていません。ページを再読み込みしてください。",
    "header.lang": "言語",
    "header.theme": "外観とテーマ",
    "language.toast": "言語：{0}",
    "memory.deleteFailed": "記憶の削除に失敗しました",
    "memory.deleted": "記憶を削除しました",
    "misc.fetchMemoriesFail": "記憶の取得に失敗しました",
    "misc.requestFailed": "リクエストに失敗しました",
    "misc.statsFail": "統計情報の取得に失敗しました",
    "nav.graph": "ナレッジグラフ",
    "nav.memory": "記憶管理",
    "nav.prompts": "プロンプト管理",
    "nav.settings": "設定",
    "settings.lead": "詳細設定",
    "settings.reloadHint": "詳細設定はこのプラグインページにあります。保存後にプラグインを再読み込みするとすべてのコンポーネントに反映されます。",
    "settings.save": "保存",
    "settings.saved": "保存しました。プラグインを再読み込みしてください",
    "settings.saveFailed": "設定の保存に失敗しました",
    "settings.loading": "設定を読み込み中…",
    "settings.loadFailed": "設定の読み込みに失敗しました",
    "settings.empty": "設定できる項目がありません",
    "settings.invalidValue": "{0} の値が不正です",
    "settings.searchPlaceholder": "設定を検索…",
    "settings.expandAll": "すべて展開",
    "settings.collapseAll": "すべて折りたたむ",
    "settings.fieldCount": "{0} 項目",
    "settings.noMatches": "一致する設定がありません",
    "settings.recommended": "よく使う",
    "settings.quickTitle": "よく使う設定",
    "settings.advancedTitle": "詳細設定（カテゴリ別・折りたたみ）",
    "settings.catMemory": "記憶の生成とライフサイクル",
    "settings.catRecall": "検索とツール",
    "settings.catGraph": "グラフと原子",
    "settings.catScope": "アクセスと分離",
    "settings.catSystem": "システムと保守",
    "nav.recall": "検索テスト",
    "nav.system": "システム概要",
    "origin.agent": "Agent 書き込み",
    "origin.auto": "自動要約",
    "origin.import": "インポート",
    "origin.resummarize": "再要約",
    "page.title": "LivingMemory コンソール",
    "pagination.next": "次へ",
    "pagination.prev": "前へ",
    "prompt.customized": "カスタマイズ済み",
    "prompt.customizedStatus": "（カスタマイズ済み）",
    "prompt.defaultFilled": "デフォルト内容を入力しました。「保存」をクリックして確定してください",
    "prompt.defaultFilledStatus": "（保存待ち：デフォルト内容）",
    "prompt.defaultStatus": "（デフォルト使用中）",
    "prompt.edit": "編集",
    "prompt.fetchFailed": "プロンプト一覧の読み込みに失敗しました",
    "prompt.jsonRequired": "このテンプレートは LLM に JSON 出力を要求する必要があります。変更すると記憶機能が壊れる可能性があります",
    "prompt.loadFailed": "プロンプト詳細の読み込みに失敗しました",
    "prompt.noPrompts": "プロンプトデータなし",
    "prompt.reset": "デフォルト内容を読み込む",
    "prompt.resetDone": "デフォルトに戻しました",
    "prompt.resetFailed": "デフォルトへの復元に失敗しました",
    "prompt.saveFailed": "プロンプトの保存に失敗しました",
    "prompt.saved": "プロンプトを保存しました",
    "prompt.variables": "利用可能な変数",
    "recall.empty": "検索結果なし · クエリを入力して検索を実行してください",
    "recall.enterQuery": "クエリを入力してください",
    "recall.fail": "検索に失敗しました",
    "recall.kLabel": "結果数 (k)",
    "recall.noMatch": "一致する記憶が見つかりません",
    "recall.queryPh": "クエリを入力して検索結果をテスト",
    "recall.resultId": "記憶 ID:",
    "recall.resultScore": "総合スコア:",
    "recall.resultsCount": "{0} 件の結果",
    "recall.searchBtn": "検索を実行",
    "recall.searching": "記憶を検索中…",
    "recall.sessionLabel": "セッション ID（任意）",
    "recall.sessionPh": "特定セッションの記憶に絞り込むセッション ID（複数形式対応）",
    "recall.time": "検索時間",
    "recall.timeElapsed": "所要時間 {0} 秒",
    "sort.createdAsc": "古い順",
    "sort.createdDesc": "新しい順",
    "sort.importanceAsc": "重要度が低い順",
    "sort.importanceDesc": "重要度が高い順",
    "sort.typeAsc": "種類 A-Z",
    "sort.updatedDesc": "更新が新しい順",
    "stats.active": "アクティブ",
    "stats.archived": "アーカイブ済み",
    "stats.atoms": "原子記憶",
    "stats.deleted": "削除済み",
    "stats.graphNodes": "グラフノード",
    "stats.sessions": "アクティブセッション",
    "stats.total": "総記憶数",
    "status.active": "アクティブ",
    "status.archived": "アーカイブ済み",
    "status.deleted": "削除済み",
    "system.atomEpisodic": "出来事",
    "system.atomFactual": "事実",
    "system.atomPlanned": "予定",
    "system.atomRelational": "関係",
    "system.atomTypes": "原子タイプ",
    "system.consGranularity": "粒度",
    "system.consGranularitySemantic": "意味的クラスタリング",
    "system.consGranularitySession": "同一セッション",
    "system.consKeep": "旧記憶",
    "system.consKeepArchive": "アーカイブ",
    "system.consKeepDelete": "削除",
    "system.consNoCandidates": "統合できる候補がありません",
    "system.consResult": "統合完了：{0} グループ、{1} 件をマージ、アーカイブ {2}、削除 {3}、失敗 {4}",
    "system.consRunning": "統合中...",
    "system.consSkipped": "スキップ（無効またはクールダウン中）",
    "system.consStatus": "ステータス",
    "system.consTrigger": "トリガー",
    "system.consTriggerDaily": "毎日",
    "system.consTriggerReflection": "リフレクション時",
    "system.consolidatedCount": "統合済み",
    "system.consolidationRun": "今すぐ統合",
    "system.consolidationTitle": "記憶統合",
    "system.fetchFailed": "システムデータの取得に失敗しました",
    "system.files": "ファイル",
    "system.importanceDistribution": "重要度分布",
    "system.memories": "件の記憶",
    "system.noAtoms": "原子データなし",
    "system.noBackups": "バックアップなし",
    "system.noSessions": "セッションなし",
    "system.sessionsTitle": "セッション（記憶数順）",
    "system.versionBackups": "バージョンバックアップ",
    "table.consolidated": "統合 {0}",
    "table.consolidatedTitle": "記憶統合による結合",
    "table.created": "作成日時",
    "table.id": "記憶 ID",
    "table.importance": "重要度",
    "table.noData": "データなし",
    "table.openMemory": "記憶 {0} を表示",
    "table.status": "ステータス",
    "table.summary": "要約",
    "table.type": "種類",
    "table.updated": "{0} に更新",
    "transfer.allowDuplicates": "重複を許可",
    "transfer.duplicateTitle": "インポート時の重複処理",
    "transfer.export": "エクスポート",
    "transfer.exportSuccess": "{0} 件の記憶をエクスポートしました",
    "transfer.exportTitle": "選択項目がある場合は選択分を、なければすべてをエクスポート",
    "transfer.failed": "記憶のインポートまたはエクスポートに失敗しました",
    "transfer.fileTooLarge": "インポートファイルは 50 MiB 以下にしてください",
    "transfer.formatTitle": "エクスポートファイル形式",
    "transfer.import": "インポート",
    "transfer.importPreview": "有効 {0} 件、インポート予定 {1} 件、重複 {2} 件、無効 {3} 件、LLM 要約が必要 {4} 件。",
    "transfer.importPreviewTitle": "記憶インポートの確認",
    "transfer.importSuccess": "{0} 件をインポート、重複スキップ {1} 件、失敗 {2} 件",
    "transfer.importTitle": "JSON または CSV の記憶ファイルをインポート",
    "transfer.skipDuplicates": "重複をスキップ",
    "type.episodic": "出来事",
    "type.event": "出来事",
    "type.fact": "事実",
    "type.factual": "事実",
    "type.general": "一般",
    "type.opinion": "意見",
    "type.planned": "予定",
    "type.preference": "好み",
    "type.relational": "関係"
  };
  Object.keys(MSG_JA).forEach((key) => {
    if (MSG[key]) MSG[key].ja = MSG_JA[key];
  });

  /* ---- Engine ---- */
  let currentLang = "zh";

  function getBridgeLocale() {
    try {
      const bridge = window.AstrBotPluginView || window.AstrBotPluginPage;
      if (bridge) {
        const ctx = bridge.getContext();
        if (ctx && ctx.locale) {
          const lang = String(ctx.locale).split("-")[0];
          if (SUPPORTED.includes(lang)) return lang;
        }
      }
    } catch (_) { /* ignore */ }
    return null;
  }

  function detectLanguage() {
    try {
      const params = new URLSearchParams(window.location.search);
      const langParam = params.get("lang");
      if (langParam && SUPPORTED.includes(langParam)) {
        urlLanguageOverride = true;
        return langParam;
      }
    } catch (_) { /* ignore */ }

    try {
      const stored = localStorage.getItem(LANG_KEY);
      if (stored && SUPPORTED.includes(stored)) return stored;
    } catch (_) { /* ignore */ }

    const bridgeLocale = getBridgeLocale();
    if (bridgeLocale) return bridgeLocale;

    try {
      const nav = (navigator.language || "").split("-")[0];
      if (SUPPORTED.includes(nav)) return nav;
    } catch (_) { /* ignore */ }

    return "zh";
  }

  function listenBridgeLocale() {
    try {
      const bridge = window.AstrBotPluginView || window.AstrBotPluginPage;
      if (!bridge || typeof bridge.onContext !== "function") return;
      bridge.onContext(function (ctx) {
        if (!ctx || !ctx.locale) return;
        const lang = String(ctx.locale).split("-")[0];
        let hasLocalOverride = false;
        try {
          hasLocalOverride = SUPPORTED.includes(localStorage.getItem(LANG_KEY));
        } catch (_) { /* ignore */ }
        if (!urlLanguageOverride && !hasLocalOverride && SUPPORTED.includes(lang) && lang !== currentLang) {
          window.setLanguage(lang, { persist: false, source: "bridge" });
        }
      });
    } catch (_) { /* ignore */ }
  }

  /**
   * @param {string} key
   * @param {...(string|number)} args - positional replacements for {0}, {1}, ...
   */
  window.t = function (key, ...args) {
    const entry = MSG[key];
    let template = entry ? (entry[currentLang] || entry.zh || key) : key;
    args.forEach((arg, i) => {
      template = template.replace(new RegExp("\\{" + i + "\\}", "g"), String(arg ?? ""));
    });
    return template;
  };

  window.setLanguage = function (lang, options = {}) {
    if (!SUPPORTED.includes(lang)) return;
    currentLang = lang;
    if (options.persist !== false) {
      try { localStorage.setItem(LANG_KEY, lang); } catch (_) { /* ignore */ }
    }
    document.documentElement.setAttribute(
      "lang",
      lang === "zh" ? "zh-CN" : lang === "ru" ? "ru" : lang === "ja" ? "ja" : "en"
    );
    applyI18n();
    window.dispatchEvent(new CustomEvent("languagechange", { detail: { lang, source: options.source || "local" } }));
  };

  window.getLanguage = function () {
    return currentLang;
  };

  function applyI18n() {
    // data-i18n → textContent
    document.querySelectorAll("[data-i18n]").forEach((el) => {
      el.textContent = window.t(el.getAttribute("data-i18n"));
    });
    // data-i18n-placeholder → placeholder
    document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
      el.setAttribute("placeholder", window.t(el.getAttribute("data-i18n-placeholder")));
    });
    // data-i18n-title → title
    document.querySelectorAll("[data-i18n-title]").forEach((el) => {
      el.setAttribute("title", window.t(el.getAttribute("data-i18n-title")));
    });
    // data-i18n-aria → aria-label
    document.querySelectorAll("[data-i18n-aria]").forEach((el) => {
      el.setAttribute("aria-label", window.t(el.getAttribute("data-i18n-aria")));
    });
  }

  // bootstrap
  currentLang = detectLanguage();
  document.documentElement.setAttribute("lang", currentLang === "zh" ? "zh-CN" : currentLang === "ru" ? "ru" : "en");
  document.addEventListener("DOMContentLoaded", () => {
    applyI18n();
    listenBridgeLocale();
  });
})();
