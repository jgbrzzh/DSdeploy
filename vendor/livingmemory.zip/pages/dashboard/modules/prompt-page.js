/**
 * Prompt Page - 提示词管理页面
 * 集中管理插件所有可自定义的提示词模板
 */

import { esc, confirmDiscardChanges } from "./utils.js";

export class PromptPage {
  constructor(state, apiClient) {
    this.state = state;
    this.api = apiClient;
    this.prompts = [];
    this.categories = [];
    this.editingId = null;
    this.editContent = null;
    this._resetMode = false;
    this._editorGeneration = 0;
  }

  /**
   * 按当前语言选择中/英文文案
   * 非中文语言优先英文字段，缺失时回退中文
   * @param {string} zhText - 中文字段
   * @param {string} enText - 英文字段
   * @returns {string}
   */
  _pickLang(zhText, enText) {
    const lang = window.getLanguage ? window.getLanguage() : "zh";
    if (lang === "zh") return zhText || enText || "";
    return enText || zhText || "";
  }

  /**
   * 获取提示词列表
   */
  async fetch() {
    try {
      const data = await this.api.get("prompts");
      this.prompts = data.prompts || [];
      this.categories = data.categories || [];
      this.state._promptError = "";
      this.updateFeedback();
      this.render();
    } catch (e) {
      this.state._promptError = e.message || window.t("prompt.fetchFailed");
      this.updateFeedback();
    }
  }

  /**
   * 渲染页面级请求反馈
   */
  updateFeedback() {
    const feedback = document.getElementById("prompt-feedback");
    const message = document.getElementById("prompt-feedback-message");
    const retry = document.getElementById("prompt-retry");
    const error = this.state._promptError || "";
    if (feedback) feedback.hidden = !error;
    if (message) message.textContent = error;
    if (retry) retry.hidden = !error;
  }

  /**
   * 渲染主页面
   */
  render() {
    const container = document.getElementById("prompt-content");
    if (!container) return;

    if (!this.prompts.length) {
      container.innerHTML =
        '<div class="table-empty">' + window.t("prompt.noPrompts") + "</div>";
      return;
    }

    // 按分类分组
    const grouped = {};
    this.prompts.forEach((p) => {
      const cat = p.category || "other";
      if (!grouped[cat]) grouped[cat] = [];
      grouped[cat].push(p);
    });

    let html = "";

    for (const [catId, prompts] of Object.entries(grouped)) {
      const catInfo = this.categories.find((c) => c.id === catId) || {};
      const catName = this._pickLang(catInfo.name, catInfo.name_en) || catId;
      // 中文界面附英文副标题，其他语言只显示当前语言名称
      const catNameAlt =
        (window.getLanguage ? window.getLanguage() : "zh") === "zh"
          ? catInfo.name_en || ""
          : "";
      const catDesc = this._pickLang(catInfo.description, catInfo.description_en);

      html += '<div class="prompt-category">';
      html +=
        '<div class="prompt-category-header">' +
        '<span class="prompt-category-name">' +
        esc(catName) +
        "</span>";
      if (catNameAlt)
        html +=
          ' <span class="prompt-category-name-en">' + esc(catNameAlt) + "</span>";
      if (catDesc)
        html +=
          '<p class="prompt-category-desc">' + esc(catDesc) + "</p>";
      html += "</div>";

      html += '<div class="prompt-list">';
      prompts.forEach((p) => {
        const customBadge = p.is_custom
          ? ' <span class="badge badge-custom">' +
            window.t("prompt.customized") +
            "</span>"
          : "";
        const jsonBadge =
          p.category === "memory_processing"
            ? ' <span class="badge badge-json-warn" title="' +
              esc(window.t("prompt.jsonRequired")) +
              '">JSON</span>'
            : "";
        const varList = (p.variables || [])
          .map((v) => '<code>' + esc(v) + "</code>")
          .join(" ");
        const descText = this._pickLang(p.description, p.description_en);

        html +=
          '<div class="prompt-item" data-id="' +
          esc(p.id) +
          '">' +
          '<div class="prompt-item-header">' +
          '<span class="prompt-item-name">' +
          esc(this._pickLang(p.name, p.name_en) || p.id) +
          jsonBadge +
          customBadge +
          "</span>";
        const nameAlt =
          (window.getLanguage ? window.getLanguage() : "zh") === "zh"
            ? p.name_en || ""
            : "";
        if (nameAlt)
          html +=
            '<span class="prompt-item-name-en">' + esc(nameAlt) + "</span>";
        html += "</div>";
        if (descText)
          html +=
            '<p class="prompt-item-desc">' + esc(descText) + "</p>";
        const usageNote = this._pickLang(p.usage_note, p.usage_note_en);
        if (usageNote)
          html +=
            '<p class="prompt-item-usage">' + esc(usageNote) + "</p>";
        if (varList)
          html +=
            '<div class="prompt-item-vars">' +
            window.t("prompt.variables") +
            ": " +
            varList +
            "</div>";
        html +=
          '<div class="prompt-item-actions">' +
          '<button class="btn btn-sm btn-secondary prompt-edit-btn" data-id="' +
          esc(p.id) +
          '"><i data-lucide="square-pen" aria-hidden="true"></i><span>' +
          window.t("prompt.edit") +
          "</span></button>" +
          "</div>";
        html += "</div>";
      });
      html += "</div></div>";
    }

    container.innerHTML = html;
    if (window.lmHydrateIcons) window.lmHydrateIcons();

    // 绑定编辑按钮事件
    container.querySelectorAll(".prompt-edit-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const id = btn.dataset.id;
        this.openEditor(id);
      });
    });
  }

  /**
   * 打开编辑器
   * @param {string} promptId - 提示词ID
   */
  async openEditor(promptId) {
    const generation = ++this._editorGeneration;
    if (!await this.canLeave() || generation !== this._editorGeneration) return;
    const prompt = this.prompts.find((p) => p.id === promptId);
    if (!prompt) return;

    this._opening = true;
    this.updateEditorControls();
    try {
      const detail = await this.api.get("prompts/detail", { id: promptId });
      if (generation !== this._editorGeneration) return;
      this.editingId = promptId;
      this.editContent = detail.content || "";

      const editorEl = document.getElementById("prompt-editor");
      if (!editorEl) return;

      document.getElementById("prompt-editor-title").textContent =
        this._pickLang(prompt.name, prompt.name_en) || prompt.id;
      document.getElementById("prompt-editor-textarea").value =
        this.editContent;
      const variables = detail.variables || [];
      document.getElementById("prompt-editor-vars").innerHTML = variables
        .map((v) => '<code class="prompt-var-tag">' + esc(v) + "</code>")
        .join(" ");
      const varsRow = document.getElementById("prompt-editor-vars-row");
      if (varsRow) varsRow.hidden = variables.length === 0;
      document.getElementById("prompt-editor-status").textContent = detail
        .is_custom
        ? " " + window.t("prompt.customizedStatus")
        : " " + window.t("prompt.defaultStatus");

      editorEl.classList.remove("hidden");

      // 绑定按钮事件
      const saveBtn = document.getElementById("prompt-save-btn");
      const resetBtn = document.getElementById("prompt-reset-btn");
      const cancelBtn = document.getElementById("prompt-cancel-btn");
      const textarea = document.getElementById("prompt-editor-textarea");

      const newSaveBtn = saveBtn.cloneNode(true);
      const newResetBtn = resetBtn.cloneNode(true);
      const newCancelBtn = cancelBtn.cloneNode(true);
      saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn);
      resetBtn.parentNode.replaceChild(newResetBtn, resetBtn);
      cancelBtn.parentNode.replaceChild(newCancelBtn, cancelBtn);

      newSaveBtn.addEventListener("click", () => this.savePrompt());
      /* 未自定义时"载入默认内容"与当前内容一致，是空操作 */
      newResetBtn.hidden = !detail.is_custom;
      newResetBtn.addEventListener("click", () => this.resetPrompt());
      newCancelBtn.addEventListener("click", () => this.closeEditor());

      // 检测修改（textarea 是常驻节点，不能像按钮一样 clone 替换；
      // 用可移除的具名 handler 防止每次打开编辑器都叠加监听）
      if (this._textareaInputHandler) {
        textarea.removeEventListener("input", this._textareaInputHandler);
      }
      this._textareaInputHandler = () => {
        // 手动编辑后退出恢复默认模式
        if (this._resetMode) {
          this._resetMode = false;
        }
        const modified = textarea.value !== this.editContent;
        const currentSaveBtn = document.getElementById("prompt-save-btn");
        if (currentSaveBtn) currentSaveBtn.disabled = this._busy || !modified;
      };
      textarea.addEventListener("input", this._textareaInputHandler);
      newSaveBtn.disabled = true;
      this._resetMode = false;

      this._opening = false;
      this.updateEditorControls();
      textarea.focus({ preventScroll: true });
      editorEl.scrollIntoView({ behavior: "smooth", block: "nearest" });
    } catch (e) {
      if (generation === this._editorGeneration) this.showToast(e.message || window.t("prompt.loadFailed"), true);
    } finally {
      if (generation === this._editorGeneration) {
        this._opening = false;
        this.updateEditorControls();
      }
    }
  }

  /**
   * 保存提示词
   */
  async savePrompt() {
    if (this._busy || !this.editingId || !this.hasUnsavedChanges()) return;
    const textarea = document.getElementById("prompt-editor-textarea");
    if (!textarea) return;
    const content = textarea.value;

    this._busy = true;
    this.updateEditorControls();
    const promptId = this.editingId;

    try {
      if (this._resetMode) {
        await this.api.post("prompts/reset", { id: promptId }, { retries: 0 });
        this._resetMode = false;
        this.showToast(window.t("prompt.resetDone"));
      } else {
        await this.api.post("prompts/update", {
          id: promptId,
          content: content,
        }, { retries: 0 });
        this.showToast(window.t("prompt.saved"));
      }
      this.editContent = content;
      await this.fetch();
      await this.closeEditor({ force: true });
    } catch (e) {
      console.error("[PromptPage] savePrompt failed:", e);
      this.showToast(e.message || window.t("prompt.saveFailed"), true);
    } finally {
      this._busy = false;
      this.updateEditorControls();
    }
  }

  /**
   * 填充默认内容到编辑器（不保存，需手动点保存）
   */
  async resetPrompt() {
    if (!await this.canLeave()) return;
    if (!this.editingId) {
      console.error("[PromptPage] resetPrompt: editingId is empty");
      return;
    }

    this._busy = true;
    this.updateEditorControls();
    const promptId = this.editingId;

    try {
      const result = await this.api.get("prompts/default", {
        id: promptId,
      });
      const newContent = result.content || "";
      const textarea = document.getElementById("prompt-editor-textarea");
      if (textarea) {
        textarea.value = newContent;
      }
      this._resetMode = true;
      const saveBtn = document.getElementById("prompt-save-btn");
      if (saveBtn) saveBtn.disabled = false;
      const statusEl = document.getElementById("prompt-editor-status");
      if (statusEl)
        statusEl.textContent = " " + window.t("prompt.defaultFilledStatus");
    } catch (e) {
      console.error("[PromptPage] resetPrompt failed:", e);
      this.showToast(e.message || window.t("prompt.resetFailed"), true);
    } finally {
      this._busy = false;
      this.updateEditorControls();
    }
  }

  /**
   * 关闭编辑器
   */
  async closeEditor({ force = false } = {}) {
    if (!force && !await this.canLeave()) return false;
    this._editorGeneration++;
    this._opening = false;
    const editorEl = document.getElementById("prompt-editor");
    if (editorEl) editorEl.classList.add("hidden");
    this.editingId = null;
    this.editContent = null;
    this._resetMode = false;
    return true;
  }

  hasUnsavedChanges() {
    if (!this.editingId) return false;
    return this._resetMode || document.getElementById("prompt-editor-textarea").value !== this.editContent;
  }

  async canLeave() {
    if (this._busy) {
      this.showToast(window.t("flow.waitForSave"));
      return false;
    }
    return !this.hasUnsavedChanges() || await confirmDiscardChanges();
  }

  updateEditorControls() {
    const feedback = document.getElementById("prompt-editor-feedback");
    if (feedback) {
      feedback.hidden = !this._busy && !this._opening;
      feedback.textContent = (this._busy || this._opening) ? window.t("flow.working") : "";
    }
    const editor = document.getElementById("prompt-editor");
    if (editor) editor.inert = Boolean(this._busy || this._opening);
    const save = document.getElementById("prompt-save-btn");
    if (save) save.disabled = this._busy || !this.hasUnsavedChanges();
    const reset = document.getElementById("prompt-reset-btn");
    if (reset) reset.disabled = Boolean(this._busy);
  }

  /**
   * 语言切换后刷新已打开编辑器的标题
   */
  refreshEditorTitle() {
    if (!this.editingId) return;
    const prompt = this.prompts.find((p) => p.id === this.editingId);
    const titleEl = document.getElementById("prompt-editor-title");
    if (prompt && titleEl) {
      titleEl.textContent = this._pickLang(prompt.name, prompt.name_en) || prompt.id;
    }
  }

  /**
   * 显示 Toast 提示
   * @param {string} message - 提示消息
   * @param {boolean} isError - 是否为错误
   */
  showToast(message, isError = false) {
    if (window.lmShowToast) {
      window.lmShowToast(message, isError);
    }
  }
}
