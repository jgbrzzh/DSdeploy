"""
Tests for MemoryEngine with a fake in-memory FaissDB.
"""

import asyncio
import json
import time
from dataclasses import dataclass
from pathlib import Path
from unittest.mock import AsyncMock, Mock

import aiosqlite
import pytest
from astrbot_plugin_livingmemory.core.managers.memory_engine import MemoryEngine
from astrbot_plugin_livingmemory.core.models.memory_atom import MemoryAtom
from astrbot_plugin_livingmemory.storage.atom_store import AtomStore


@dataclass
class _FakeRetrieveResult:
    similarity: float
    data: dict


class _FakeDocumentStorage:
    def __init__(self, db: "_FakeFaissDB"):
        self._db = db

    async def get_documents(self, metadata_filters, ids=None, limit=50, offset=0):
        docs = list(self._db.docs.values())
        if ids is not None:
            id_set = set(ids)
            docs = [d for d in docs if d["id"] in id_set]

        for key, value in (metadata_filters or {}).items():
            docs = [d for d in docs if d["metadata"].get(key) == value]

        docs = docs[offset : offset + limit]
        return [dict(d) for d in docs]

    async def count_documents(self, metadata_filters):
        docs = list(self._db.docs.values())
        for key, value in (metadata_filters or {}).items():
            docs = [d for d in docs if d["metadata"].get(key) == value]
        return len(docs)


class _FakeFaissDB:
    def __init__(self):
        self.docs: dict[int, dict] = {}
        self._next_id = 1
        self.document_storage = _FakeDocumentStorage(self)

    async def insert(self, content: str, metadata: dict) -> int:
        doc_id = self._next_id
        self._next_id += 1
        self.docs[doc_id] = {
            "id": doc_id,
            "doc_id": f"uuid-{doc_id}",
            "text": content,
            "metadata": dict(metadata),
        }
        return doc_id

    async def retrieve(
        self, query: str, k: int, fetch_k: int, rerank: bool, metadata_filters=None
    ):
        results: list[_FakeRetrieveResult] = []
        for doc in self.docs.values():
            if metadata_filters:
                ok = True
                for key, value in metadata_filters.items():
                    if doc["metadata"].get(key) != value:
                        ok = False
                        break
                if not ok:
                    continue

            text = doc["text"]
            score = 0.9 if query in text else 0.2
            results.append(
                _FakeRetrieveResult(
                    similarity=score,
                    data={
                        "id": doc["id"],
                        "text": text,
                        "metadata": dict(doc["metadata"]),
                    },
                )
            )

        results.sort(key=lambda x: x.similarity, reverse=True)
        return results[:k]

    async def delete(self, uuid_doc_id: str) -> None:
        target = None
        for did, doc in self.docs.items():
            if doc["doc_id"] == uuid_doc_id:
                target = did
                break
        if target is not None:
            self.docs.pop(target, None)

    async def close(self) -> None:
        return None


def test_memory_engine_atom_enabled_honors_explicit_false(tmp_path: Path):
    engine = MemoryEngine(
        db_path=str(tmp_path / "memory.db"),
        faiss_db=_FakeFaissDB(),
        config={"atom_enabled": False},
    )

    assert engine.atom_enabled is False


@pytest.mark.asyncio
async def test_initialize_drops_legacy_documents_fts_triggers(tmp_path: Path):
    db_path = tmp_path / "legacy_trigger.db"
    async with aiosqlite.connect(db_path) as db:
        await db.execute("""
            CREATE TABLE documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                metadata TEXT DEFAULT '{}'
            )
        """)
        await db.execute("""
            CREATE TRIGGER documents_au AFTER UPDATE ON documents BEGIN
                INSERT INTO documents_fts(rowid, content, doc_id)
                VALUES (new.id, new.text, new.doc_id);
            END
        """)
        await db.commit()

    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={"fallback_enabled": True, "rrf_k": 60},
    )
    await engine.initialize()
    await engine.close()

    async with aiosqlite.connect(db_path) as db:
        cursor = await db.execute("""
            SELECT name FROM sqlite_master
            WHERE type='trigger' AND name='documents_au'
        """)
        row = await cursor.fetchone()

    assert row is None


@pytest.mark.asyncio
async def test_failed_shared_write_rolls_back_and_releases_other_connections(
    tmp_path: Path,
):
    db_path = tmp_path / "failed_write.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={"fallback_enabled": True, "rrf_k": 60},
    )
    await engine.initialize()
    async with engine.db_connection.execute("""
        CREATE TRIGGER reject_memory_source
        BEFORE INSERT ON memory_sources
        BEGIN
            SELECT RAISE(ABORT, 'source blocked');
        END
    """):
        await engine.db_connection.commit()

    with pytest.raises(Exception, match="source blocked"):
        await engine.save_memory_source(1, [{"content": "will fail"}])

    assert engine.db_connection.in_transaction is False
    async with aiosqlite.connect(db_path, timeout=0.2) as other:
        await other.execute(
            "INSERT INTO documents(doc_id, text, metadata) VALUES (?, ?, ?)",
            ("other-doc", "other connection write", "{}"),
        )
        await other.commit()

    await engine.close()


@pytest.mark.asyncio
async def test_write_transaction_clears_stale_transaction_before_writing(tmp_path: Path):
    db_path = tmp_path / "stale_write.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={"fallback_enabled": True, "rrf_k": 60},
    )
    await engine.initialize()
    await engine.db_connection.execute("BEGIN IMMEDIATE")
    await engine.db_connection.execute(
        "INSERT INTO documents(doc_id, text, metadata) VALUES (?, ?, ?)",
        ("stale-doc", "uncommitted", "{}"),
    )

    await engine.save_memory_source(1, [{"content": "committed"}])

    assert engine.db_connection.in_transaction is False
    async with aiosqlite.connect(db_path, timeout=0.2) as other:
        cursor = await other.execute("SELECT COUNT(*) FROM memory_sources")
        assert (await cursor.fetchone())[0] == 1
        cursor = await other.execute(
            "SELECT COUNT(*) FROM documents WHERE doc_id = 'stale-doc'"
        )
        assert (await cursor.fetchone())[0] == 0

    await engine.close()


@pytest.mark.asyncio
async def test_swallowed_access_update_error_releases_other_connections(
    tmp_path: Path,
):
    db_path = tmp_path / "access_update_error.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={"fallback_enabled": True, "rrf_k": 60},
    )
    await engine.initialize()
    await engine.db_connection.execute(
        "INSERT INTO documents(doc_id, text, metadata) VALUES (?, ?, ?)",
        ("access-doc", "access update", '{"access_count": 0}'),
    )
    await engine.db_connection.execute(
        "CREATE TABLE memory_atoms (id INTEGER PRIMARY KEY, status TEXT, expires_at REAL)"
    )
    await engine.db_connection.execute("""
        CREATE TRIGGER reject_atom_touch
        BEFORE UPDATE ON memory_atoms
        BEGIN
            SELECT RAISE(ABORT, 'atom blocked');
        END
    """)
    await engine.db_connection.commit()
    engine.atom_store = Mock()

    written = await engine._write_access_updates([1], [1])

    assert written is False
    assert engine.db_connection.in_transaction is False
    async with aiosqlite.connect(db_path, timeout=0.2) as other:
        cursor = await other.execute("SELECT metadata FROM documents WHERE id = 1")
        metadata = json.loads((await cursor.fetchone())[0])
        assert metadata == {"access_count": 0}
        await other.execute("UPDATE documents SET text = ? WHERE id = 1", ("recovered",))
        await other.commit()

    await engine.close()


@pytest.mark.asyncio
async def test_memory_engine_add_search_get_delete(tmp_path: Path):
    db_path = tmp_path / "memory.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={"fallback_enabled": True, "rrf_k": 60},
    )
    await engine.initialize()

    memory_id = await engine.add_memory(
        content="我喜欢吃苹果",
        session_id="test:private:s1",
        persona_id="persona_1",
        importance=0.8,
        metadata={"topics": ["饮食"]},
    )
    assert memory_id > 0

    result = await engine.get_memory(memory_id)
    assert result is not None
    assert "苹果" in result["text"]

    searched = await engine.search_memories(
        query="苹果",
        k=3,
        session_id="test:private:s1",
        persona_id="persona_1",
    )
    assert len(searched) >= 1
    assert searched[0].doc_id == memory_id

    ok_delete = await engine.delete_memory(memory_id)
    assert ok_delete is True
    assert await engine.get_memory(memory_id) is None
    await engine.close()


@pytest.mark.asyncio
async def test_memory_source_is_separate_transferred_and_deleted(tmp_path: Path):
    engine = MemoryEngine(
        db_path=str(tmp_path / "memory_source.db"),
        faiss_db=_FakeFaissDB(),
        config={"fallback_enabled": True},
    )
    await engine.initialize()
    source = [
        {
            "id": 1,
            "session_id": "s1",
            "role": "user",
            "content": "exact source detail",
            "sender_id": "u1",
            "timestamp": 100.0,
            "metadata": {},
        }
    ]
    memory_id = await engine.add_memory(
        content="summary",
        session_id="s1",
        metadata={},
        source_messages=source,
    )

    stored = await engine.get_memory(memory_id)
    assert stored["metadata"]["has_source"] is True
    assert "exact source detail" not in str(stored["metadata"])
    assert await engine.get_memory_source(memory_id) == source

    new_id = await engine.replace_memory(
        memory_id,
        content="new summary",
        importance=0.8,
        metadata=stored["metadata"],
    )
    assert await engine.get_memory_source(memory_id) == []
    assert await engine.get_memory_source(new_id) == source

    assert await engine.delete_memory(new_id) is True
    assert await engine.get_memory_source(new_id) == []
    await engine.close()


@pytest.mark.asyncio
async def test_memory_transfer_records_include_source_and_duplicate_key(tmp_path: Path):
    engine = MemoryEngine(
        db_path=str(tmp_path / "memory_transfer.db"),
        faiss_db=_FakeFaissDB(),
        config={"fallback_enabled": True},
    )
    await engine.initialize()
    source = [
        {
            "id": 1,
            "session_id": "s1",
            "role": "user",
            "content": "exact detail",
            "sender_id": "u1",
            "timestamp": 1.0,
            "metadata": {},
        }
    ]
    memory_id = await engine.add_memory(
        content="portable summary",
        session_id="s1",
        persona_id="p1",
        importance=0.9,
        metadata={"topics": ["portable"]},
        source_messages=source,
    )
    await engine.db_connection.execute(
        "INSERT INTO documents (id, doc_id, text, metadata, created_at, updated_at) "
        "VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
        (
            memory_id,
            f"uuid-{memory_id}",
            "portable summary",
            json.dumps(engine.faiss_db.docs[memory_id]["metadata"]),
        ),
    )
    await engine.db_connection.commit()

    records = await engine.get_memory_transfer_records([memory_id])
    keys = await engine.get_memory_import_keys()

    assert records[0]["content"] == "portable summary"
    assert records[0]["source_messages"] == source
    assert ("portable summary", "s1", "p1") in keys
    await engine.close()


@pytest.mark.asyncio
async def test_memory_transfer_records_batches_more_than_500_selected_ids(
    tmp_path: Path,
):
    engine = MemoryEngine(
        db_path=str(tmp_path / "memory_transfer_batches.db"),
        faiss_db=_FakeFaissDB(),
        config={"fallback_enabled": True},
    )
    await engine.initialize()
    assert engine.db_connection is not None
    rows = [
        (
            memory_id,
            f"uuid-{memory_id}",
            f"memory {memory_id}",
            json.dumps({"importance": 0.5}),
        )
        for memory_id in range(1, 502)
    ]
    await engine.db_connection.executemany(
        "INSERT INTO documents (id, doc_id, text, metadata, created_at, updated_at) "
        "VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
        rows,
    )
    await engine.db_connection.commit()

    records = await engine.get_memory_transfer_records(list(range(501, 0, -1)))

    assert len(records) == 501
    assert [record["original_id"] for record in records] == list(range(1, 502))
    await engine.close()


@pytest.mark.asyncio
async def test_memory_source_write_failure_rolls_back_indexed_memory(tmp_path: Path):
    engine = MemoryEngine(
        db_path=str(tmp_path / "memory_source_failure.db"),
        faiss_db=_FakeFaissDB(),
        config={"fallback_enabled": True},
    )
    await engine.initialize()
    engine.save_memory_source = AsyncMock(side_effect=RuntimeError("disk full"))

    with pytest.raises(RuntimeError, match="disk full"):
        await engine.add_memory(
            content="summary",
            session_id="s1",
            source_messages=[{"role": "user", "content": "source"}],
        )

    assert await engine.get_memory(1) is None
    await engine.close()




@pytest.mark.asyncio
async def test_memory_engine_decay_and_cleanup(tmp_path: Path):
    db_path = tmp_path / "memory_decay.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={"cleanup_days_threshold": 1, "cleanup_importance_threshold": 0.3},
    )
    await engine.initialize()

    old_id = await engine.add_memory(
        content="旧记忆",
        session_id="s",
        persona_id="p",
        importance=0.2,
        metadata={"topics": ["old"]},
    )
    new_id = await engine.add_memory(
        content="新记忆",
        session_id="s",
        persona_id="p",
        importance=0.9,
        metadata={"topics": ["new"]},
    )
    assert old_id != new_id

    # Make old memory older than threshold in fake storage and sqlite table.
    old_time = time.time() - 86400 * 3
    engine.faiss_db.docs[old_id]["metadata"]["create_time"] = old_time
    engine.faiss_db.docs[old_id]["metadata"]["last_access_time"] = old_time

    if engine.db_connection is not None:
        await engine.db_connection.execute(
            "INSERT OR REPLACE INTO documents (id, doc_id, text, metadata, created_at, updated_at) VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
            (
                old_id,
                f"uuid-{old_id}",
                "旧记忆",
                json.dumps(
                    {
                        "importance": 0.2,
                        "create_time": old_time,
                        "last_access_time": old_time,
                    },
                    ensure_ascii=False,
                ),
            ),
        )
        await engine.db_connection.execute(
            "INSERT OR REPLACE INTO documents (id, doc_id, text, metadata, created_at, updated_at) VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
            (
                new_id,
                f"uuid-{new_id}",
                "新记忆",
                json.dumps(
                    {
                        "importance": 0.9,
                        "create_time": time.time(),
                        "last_access_time": time.time(),
                    },
                    ensure_ascii=False,
                ),
            ),
        )
        await engine.db_connection.commit()

    decayed = await engine.apply_daily_decay(decay_rate=0.1, days=2)
    assert isinstance(decayed, int)

    deleted = await engine.cleanup_old_memories(
        days_threshold=1, importance_threshold=0.3
    )
    assert deleted >= 1

    stats = await engine.get_statistics()
    assert "total_memories" in stats

    await engine.close()


@pytest.mark.asyncio
async def test_daily_decay_skips_protected_importance_threshold(tmp_path: Path):
    engine = MemoryEngine(
        db_path=str(tmp_path / "protected_decay.db"),
        faiss_db=_FakeFaissDB(),
        config={"protected_importance_threshold": 0.8},
    )
    await engine.initialize()
    now = time.time()
    rows = [
        (101, "uuid-101", "protected", 0.9),
        (102, "uuid-102", "decaying", 0.5),
    ]
    for memory_id, uuid, text, importance in rows:
        metadata = json.dumps(
            {
                "importance": importance,
                "create_time": now,
                "last_access_time": now,
                "access_count": 0,
            }
        )
        await engine.db_connection.execute(
            "INSERT INTO documents "
            "(id, doc_id, text, metadata, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
            (memory_id, uuid, text, metadata),
        )
    await engine.db_connection.commit()

    affected = await engine.apply_daily_decay(0.1)
    cursor = await engine.db_connection.execute(
        "SELECT id, metadata FROM documents WHERE id IN (101, 102) ORDER BY id"
    )
    stored = {
        int(row["id"]): json.loads(row["metadata"])["importance"]
        for row in await cursor.fetchall()
    }

    assert affected == 1
    assert stored[101] == 0.9
    assert stored[102] == 0.45
    await engine.close()


@pytest.mark.asyncio
async def test_memory_engine_search_updates_access_time_async(tmp_path: Path):
    db_path = tmp_path / "memory_access.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={"fallback_enabled": True},
    )
    await engine.initialize()

    mid = await engine.add_memory(
        content="测试访问时间",
        session_id="test:private:s1",
        persona_id="p1",
        importance=0.5,
        metadata={},
    )

    await engine.search_memories(
        "测试", k=1, session_id="test:private:s1", persona_id="p1"
    )
    await asyncio.sleep(0.05)
    # Access-time update may fail silently if row absent in sqlite documents table;
    # function should still complete and return results.
    assert mid in engine.faiss_db.docs
    await engine.close()


@pytest.mark.asyncio
async def test_internal_memory_scope_skips_legacy_session_migration(tmp_path: Path):
    engine = MemoryEngine(
        db_path=str(tmp_path / "internal_scope.db"),
        faiss_db=_FakeFaissDB(),
        config={"fallback_enabled": True},
    )
    await engine.initialize()
    engine._migrate_session_data_if_needed = AsyncMock()

    await engine.search_memories(
        "shared memory",
        session_id="livingmemory:user:test:user-1",
    )

    engine._migrate_session_data_if_needed.assert_not_awaited()
    await engine.close()


@pytest.mark.asyncio
async def test_search_memories_filters_below_minimum_importance(tmp_path: Path):
    engine = MemoryEngine(
        db_path=str(tmp_path / "memory_threshold.db"),
        faiss_db=_FakeFaissDB(),
        config={
            "min_importance_for_retrieval": 0.6,
            "search_cache_enabled": False,
        },
    )
    engine.hybrid_retriever = Mock()
    engine.hybrid_retriever.search = AsyncMock(
        return_value=[
            Mock(doc_id=1, metadata={"importance": 0.8}),
            Mock(doc_id=2, metadata={"importance": 0.59}),
            Mock(doc_id=3, metadata={}),
        ]
    )

    results = await engine.search_memories("query", k=5)

    assert [result.doc_id for result in results] == [1]
    await asyncio.gather(*engine._pending_tasks)


@pytest.mark.asyncio
async def test_search_memories_zero_importance_threshold_preserves_results(
    tmp_path: Path,
):
    engine = MemoryEngine(
        db_path=str(tmp_path / "memory_no_threshold.db"),
        faiss_db=_FakeFaissDB(),
        config={
            "min_importance_for_retrieval": 0.0,
            "search_cache_enabled": False,
        },
    )
    expected = [Mock(doc_id=1, metadata={"importance": 0.01})]
    engine.hybrid_retriever = Mock()
    engine.hybrid_retriever.search = AsyncMock(return_value=expected)

    results = await engine.search_memories("query", k=5)

    assert results == expected
    await asyncio.gather(*engine._pending_tasks)


@pytest.mark.asyncio
async def test_search_memories_applies_vector_similarity_threshold(tmp_path: Path):
    engine = MemoryEngine(
        db_path=str(tmp_path / "memory_similarity.db"),
        faiss_db=_FakeFaissDB(),
        config={
            "min_similarity_for_retrieval": 0.7,
            "recent_memory_count": 0,
            "search_cache_enabled": False,
        },
    )
    keyword_only = Mock(
        doc_id=3,
        metadata={"importance": 0.5},
        vector_score=None,
        score_breakdown={},
    )
    engine.hybrid_retriever = Mock()
    engine.hybrid_retriever.search = AsyncMock(
        return_value=[
            Mock(
                doc_id=1,
                metadata={"importance": 0.8},
                vector_score=0.82,
                score_breakdown={},
            ),
            Mock(
                doc_id=2,
                metadata={"importance": 0.8},
                vector_score=0.69,
                score_breakdown={},
            ),
            keyword_only,
        ]
    )

    results = await engine.search_memories("query", k=5)

    assert [result.doc_id for result in results] == [1, 3]
    await asyncio.gather(*engine._pending_tasks)


@pytest.mark.asyncio
async def test_search_memories_event_only_keeps_legacy_and_event_types(tmp_path: Path):
    engine = MemoryEngine(
        db_path=str(tmp_path / "memory_types.db"),
        faiss_db=_FakeFaissDB(),
        config={
            "memory_type_filter": "event_only",
            "recent_memory_count": 0,
            "search_cache_enabled": False,
        },
    )
    engine.hybrid_retriever = Mock()
    engine.hybrid_retriever.search = AsyncMock(
        return_value=[
            Mock(doc_id=1, metadata={"atom_types": ["episodic"]}),
            Mock(doc_id=2, metadata={"atom_types": ["preference"]}),
            Mock(doc_id=3, metadata={}),
        ]
    )

    results = await engine.search_memories("query", k=5)

    assert [result.doc_id for result in results] == [1, 3]
    await asyncio.gather(*engine._pending_tasks)


@pytest.mark.asyncio
async def test_recent_memory_slots_are_reserved_without_duplicates(tmp_path: Path):
    engine = MemoryEngine(
        db_path=str(tmp_path / "recent_slots.db"),
        faiss_db=_FakeFaissDB(),
        config={"recent_memory_count": 2},
    )
    relevant = [Mock(doc_id=value) for value in (1, 2, 3, 4)]
    engine._get_recent_memory_results = AsyncMock(
        return_value=[Mock(doc_id=4), Mock(doc_id=5)]
    )

    merged = await engine._merge_recent_memories(relevant, 4, "session", "persona")

    assert [result.doc_id for result in merged] == [1, 2, 4, 5]


@pytest.mark.asyncio
async def test_memory_engine_search_cache_reuses_results_and_invalidates_on_write(
    tmp_path: Path,
):
    db_path = tmp_path / "memory_cache.db"
    faiss = _FakeFaissDB()
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=faiss,
        config={
            "fallback_enabled": True,
            "search_cache_enabled": True,
            "search_cache_ttl_seconds": 60,
            "search_cache_max_size": 8,
        },
    )
    await engine.initialize()

    await engine.add_memory(
        content="缓存测试：用户喜欢苹果",
        session_id="test:private:s1",
        persona_id="p1",
        importance=0.8,
        metadata={},
    )

    calls = 0
    original_search = engine.hybrid_retriever.search

    async def counted_search(*args, **kwargs):
        nonlocal calls
        calls += 1
        return await original_search(*args, **kwargs)

    engine.hybrid_retriever.search = counted_search

    first = await engine.search_memories(
        query="苹果", k=3, session_id="test:private:s1", persona_id="p1"
    )
    second = await engine.search_memories(
        query="  苹果  ", k=3, session_id="test:private:s1", persona_id="p1"
    )
    assert [item.doc_id for item in second] == [item.doc_id for item in first]
    assert calls == 1

    await engine.add_memory(
        content="缓存测试：用户喜欢香蕉",
        session_id="test:private:s1",
        persona_id="p1",
        importance=0.8,
        metadata={},
    )
    await engine.search_memories(
        query="苹果", k=3, session_id="test:private:s1", persona_id="p1"
    )
    assert calls == 2

    await engine.close()



@pytest.mark.asyncio
async def test_memory_engine_atom_fallback_skips_previously_inserted_atoms(
    tmp_path: Path,
):
    db_path = tmp_path / "atom_partial_fallback.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={"graph_memory_enabled": True, "graph_memory_atom_enabled": True},
    )
    await engine.initialize()
    engine.atom_store = Mock()
    engine.atom_store.insert_many = AsyncMock(side_effect=RuntimeError("batch failed"))
    engine.atom_store.insert = AsyncMock()

    inserted_atom = MemoryAtom(parent_memory_id=0, content="already inserted")
    inserted_atom.atom_id = 42
    pending_atom = MemoryAtom(parent_memory_id=0, content="pending insert")

    memory_id = await engine.add_memory(
        content="fallback atom test",
        session_id="s1",
        persona_id="p1",
        atoms=[inserted_atom, pending_atom],
    )

    assert memory_id > 0
    engine.atom_store.insert.assert_awaited_once_with(pending_atom)

    await engine.close()



@pytest.mark.asyncio
async def test_memory_engine_access_count_increments_and_slows_decay(tmp_path: Path):
    db_path = tmp_path / "access_decay.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={
            "access_decay_window_days": 30,
            "access_decay_max_count": 10,
            "access_count_decay_multiplier": 0.5,
        },
    )
    await engine.initialize()

    now = time.time()
    low_access_id = await engine.add_memory(
        content="低访问记忆",
        session_id="s1",
        persona_id="p1",
        importance=0.8,
        metadata={},
    )
    high_access_id = await engine.add_memory(
        content="高访问记忆",
        session_id="s1",
        persona_id="p1",
        importance=0.8,
        metadata={},
    )

    await engine.db_connection.execute(
        """
        INSERT OR REPLACE INTO documents(
            id, doc_id, text, metadata, created_at, updated_at
        ) VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
        """,
        (
            low_access_id,
            f"uuid-{low_access_id}",
            "低访问记忆",
            json.dumps(
                {
                    "importance": 0.8,
                    "last_access_time": now,
                    "access_count": 0,
                }
            ),
        ),
    )
    await engine.db_connection.execute(
        """
        INSERT OR REPLACE INTO documents(
            id, doc_id, text, metadata, created_at, updated_at
        ) VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
        """,
        (
            high_access_id,
            f"uuid-{high_access_id}",
            "高访问记忆",
            json.dumps(
                {
                    "importance": 0.8,
                    "last_access_time": now,
                    "access_count": 10,
                }
            ),
        ),
    )
    await engine.db_connection.commit()

    await engine._update_access_time_internal(low_access_id)
    cursor = await engine.db_connection.execute(
        "SELECT metadata FROM documents WHERE id = ?",
        (low_access_id,),
    )
    row = await cursor.fetchone()
    assert json.loads(row["metadata"])["access_count"] == 1

    affected = await engine.apply_daily_decay(decay_rate=0.1, days=1)
    assert affected >= 2

    cursor = await engine.db_connection.execute(
        "SELECT id, metadata FROM documents WHERE id IN (?, ?)",
        (low_access_id, high_access_id),
    )
    rows = await cursor.fetchall()
    metadata_by_id = {row["id"]: json.loads(row["metadata"]) for row in rows}
    assert (
        metadata_by_id[high_access_id]["importance"]
        > metadata_by_id[low_access_id]["importance"]
    )
    assert metadata_by_id[high_access_id]["access_count"] == 5

    await engine.close()


# ── MemoryEngine 过滤/衰减/清理边界测试 ──────────────────────────────────────


@pytest.mark.asyncio
async def test_memory_engine_session_filter_isolates_sessions(tmp_path: Path):
    """不同 session_id 的记忆应相互隔离，搜索时只返回匹配 session 的结果。"""
    db_path = tmp_path / "filter.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={"fallback_enabled": True},
    )
    await engine.initialize()

    await engine.add_memory(
        content="session A 的记忆：用户喜欢苹果",
        session_id="test:private:session_A",
        persona_id="p1",
        importance=0.8,
        metadata={},
    )
    await engine.add_memory(
        content="session B 的记忆：用户喜欢香蕉",
        session_id="test:private:session_B",
        persona_id="p1",
        importance=0.8,
        metadata={},
    )

    results_a = await engine.search_memories(
        query="苹果",
        k=5,
        session_id="test:private:session_A",
        persona_id="p1",
    )
    # session A 的搜索不应返回 session B 的记忆
    for r in results_a:
        assert r.metadata.get("session_id") == "test:private:session_A"

    await engine.close()


@pytest.mark.asyncio
async def test_memory_engine_apply_daily_decay_zero_rate_returns_zero(tmp_path: Path):
    """decay_rate=0 时，apply_daily_decay 应直接返回 0，不修改任何记忆。"""
    db_path = tmp_path / "decay_zero.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()

    await engine.add_memory(
        content="测试记忆",
        session_id="s1",
        persona_id="p1",
        importance=0.8,
        metadata={},
    )

    result = await engine.apply_daily_decay(decay_rate=0, days=1)
    assert result == 0

    await engine.close()


@pytest.mark.asyncio
async def test_memory_engine_apply_daily_decay_zero_days_returns_zero(tmp_path: Path):
    """days=0 时，apply_daily_decay 应直接返回 0。"""
    db_path = tmp_path / "decay_days_zero.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()

    await engine.add_memory(
        content="测试记忆",
        session_id="s1",
        persona_id="p1",
        importance=0.8,
        metadata={},
    )

    result = await engine.apply_daily_decay(decay_rate=0.1, days=0)
    assert result == 0

    await engine.close()


@pytest.mark.asyncio
async def test_memory_engine_apply_daily_decay_reduces_importance(tmp_path: Path):
    """apply_daily_decay 应降低记忆的 importance 值。"""
    db_path = tmp_path / "decay_reduce.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()

    mid = await engine.add_memory(
        content="重要记忆",
        session_id="s1",
        persona_id="p1",
        importance=0.8,
        metadata={},
    )

    # 手动在 SQLite 中写入 importance，确保衰减可以读取
    if engine.db_connection is not None:
        await engine.db_connection.execute(
            "UPDATE documents SET metadata = ? WHERE id = ?",
            (json.dumps({"importance": 0.8, "session_id": "s1"}), mid),
        )
        await engine.db_connection.commit()

    affected = await engine.apply_daily_decay(decay_rate=0.1, days=1)
    assert isinstance(affected, int)
    assert affected >= 0

    await engine.close()


@pytest.mark.asyncio
async def test_memory_engine_cleanup_negative_days_returns_zero(tmp_path: Path):
    """days_threshold < 0 时，cleanup_old_memories 应返回 0。"""
    db_path = tmp_path / "cleanup_neg.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()

    await engine.add_memory(
        content="旧记忆",
        session_id="s1",
        persona_id="p1",
        importance=0.1,
        metadata={},
    )

    result = await engine.cleanup_old_memories(
        days_threshold=-1, importance_threshold=0.5
    )
    assert result == 0

    await engine.close()


@pytest.mark.asyncio
async def test_daily_decay_preserves_concurrent_access_updates(
    tmp_path: Path, monkeypatch
):
    """衰减落库只改 importance/access_count，快照后并发写入的访问时间不能被覆盖。"""
    import sqlite3

    import astrbot_plugin_livingmemory.core.managers.memory_engine_crud as crud_mod

    db_path = tmp_path / "decay_race.db"
    engine = MemoryEngine(db_path=str(db_path), faiss_db=_FakeFaissDB(), config={})
    await engine.initialize()
    memory_id = await engine.add_memory(
        content="race",
        session_id="s1",
        persona_id="p1",
        importance=0.5,
        metadata={},
    )
    await engine.db_connection.execute(
        "INSERT OR REPLACE INTO documents "
        "(id, doc_id, text, metadata, created_at, updated_at) "
        "VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
        (
            memory_id,
            f"uuid-{memory_id}",
            "race",
            json.dumps(
                {"importance": 0.5, "access_count": 0, "last_access_time": 1.0}
            ),
        ),
    )
    await engine.db_connection.commit()

    real_to_thread = asyncio.to_thread
    concurrent_time = 1234567890.0

    async def racing_to_thread(func, *args, **kwargs):
        result = await real_to_thread(func, *args, **kwargs)
        # 模拟快照读取之后、衰减落库之前的并发召回写入
        con = sqlite3.connect(str(db_path))
        try:
            con.execute(
                "UPDATE documents SET metadata = json_set("
                "json_set(metadata, '$.last_access_time', ?), "
                "'$.access_count', 10) WHERE id = ?",
                (concurrent_time, memory_id),
            )
            con.commit()
        finally:
            con.close()
        return result

    monkeypatch.setattr(crud_mod.asyncio, "to_thread", racing_to_thread)
    affected = await engine.apply_daily_decay(decay_rate=0.1, days=1)
    assert affected == 1

    cursor = await engine.db_connection.execute(
        "SELECT metadata FROM documents WHERE id = ?", (memory_id,)
    )
    row = await cursor.fetchone()
    metadata = json.loads(row["metadata"])
    assert metadata["last_access_time"] == concurrent_time
    assert metadata["access_count"] == 5
    assert metadata["importance"] < 0.5
    await engine.close()


@pytest.mark.asyncio
async def test_memory_engine_cleanup_zero_days_deletes_low_importance(tmp_path: Path):
    """days_threshold=0 时，所有低重要性记忆（无论多新）都应被清理。"""
    db_path = tmp_path / "cleanup_zero.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()

    low_id = await engine.add_memory(
        content="低重要性记忆",
        session_id="s1",
        persona_id="p1",
        importance=0.1,
        metadata={},
    )
    high_id = await engine.add_memory(
        content="高重要性记忆",
        session_id="s1",
        persona_id="p1",
        importance=0.9,
        metadata={},
    )

    # 确保 SQLite documents 表与 fake FAISS 存储保持一致。
    # create_time 取 1 秒前：days_threshold=0 的比较是严格小于，若写入与清理
    # 落在同一时钟刻度内，candidate 会被漏掉（Windows 上偶发失败）。
    now = time.time() - 1.0
    if engine.db_connection is not None:
        await engine.db_connection.execute(
            "INSERT OR REPLACE INTO documents "
            "(id, doc_id, text, metadata, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
            (
                low_id,
                f"uuid-{low_id}",
                "低重要性记忆",
                json.dumps({"importance": 0.1, "create_time": now}),
            ),
        )
        await engine.db_connection.execute(
            "INSERT OR REPLACE INTO documents "
            "(id, doc_id, text, metadata, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
            (
                high_id,
                f"uuid-{high_id}",
                "高重要性记忆",
                json.dumps({"importance": 0.9, "create_time": now}),
            ),
        )
        await engine.db_connection.commit()

    deleted = await engine.cleanup_old_memories(
        days_threshold=0, importance_threshold=0.5
    )
    assert deleted >= 1
    assert await engine.get_memory(high_id) is not None

    await engine.close()


@pytest.mark.asyncio
async def test_memory_engine_update_memory_content_creates_new_deletes_old(
    tmp_path: Path,
):
    """update_memory 更新内容时，应先创建新记忆再删除旧记忆。"""
    db_path = tmp_path / "update.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()

    old_id = await engine.add_memory(
        content="旧内容",
        session_id="s1",
        persona_id="p1",
        importance=0.7,
        metadata={},
    )

    success = await engine.update_memory(old_id, {"content": "新内容"})
    assert success is True
    assert await engine.get_memory(old_id) is None

    await engine.close()


@pytest.mark.asyncio
async def test_memory_engine_update_memory_importance_only(tmp_path: Path):
    """update_memory 只更新 importance 时，不应崩溃（fake DB 不支持 get_session，返回 False 是预期行为）。"""
    db_path = tmp_path / "update_imp.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()

    mid = await engine.add_memory(
        content="测试记忆",
        session_id="s1",
        persona_id="p1",
        importance=0.5,
        metadata={},
    )

    # fake DB 不支持 get_session，update_metadata 会失败，但不应抛出异常
    result = await engine.update_memory(mid, {"importance": 0.9})
    assert isinstance(result, bool)  # 不崩溃即可
    # 记忆仍然存在（内容未被删除）
    assert await engine.get_memory(mid) is not None

    await engine.close()


@pytest.mark.asyncio
async def test_memory_engine_delete_nonexistent_returns_false(tmp_path: Path):
    """删除不存在的记忆 ID 应返回 False。"""
    db_path = tmp_path / "del_nonexist.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()

    result = await engine.delete_memory(99999)
    assert result is False

    await engine.close()


@pytest.mark.asyncio
async def test_memory_engine_search_empty_query_returns_empty(tmp_path: Path):
    """空查询应直接返回空列表。"""
    db_path = tmp_path / "empty_query.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()

    await engine.add_memory(
        content="一些记忆内容",
        session_id="s1",
        persona_id="p1",
        importance=0.5,
        metadata={},
    )

    assert await engine.search_memories("", k=5) == []
    assert await engine.search_memories("   ", k=5) == []

    await engine.close()


@pytest.mark.asyncio
async def test_memory_engine_get_statistics_returns_expected_keys(tmp_path: Path):
    """get_statistics 应返回包含 total_memories 等关键字段的字典。"""
    db_path = tmp_path / "stats.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()

    await engine.add_memory(
        content="统计测试记忆",
        session_id="s1",
        persona_id="p1",
        importance=0.6,
        metadata={},
    )

    stats = await engine.get_statistics()
    assert "total_memories" in stats

    await engine.close()


# ── MemoryEngine.batch_delete_memories 测试 ───────────────────────────────────


@pytest.mark.asyncio
async def test_batch_delete_memories_deletes_multiple(tmp_path: Path):
    """batch_delete_memories 应批量删除多条记忆（从 FAISS 和 SQLite documents 表）。"""
    db_path = tmp_path / "batch_del.db"
    faiss = _FakeFaissDB()
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=faiss,
        config={},
    )
    await engine.initialize()

    # 直接在 FAISS 和 SQLite 中构造数据，避免 add_memory 锁竞争
    ids = []
    for i in range(5):
        mid = faiss._next_id
        faiss._next_id += 1
        faiss.docs[mid] = {
            "id": mid,
            "doc_id": f"uuid-{mid}",
            "text": f"批量删除测试记忆{i}",
            "metadata": {"importance": 0.5, "session_id": "s1", "persona_id": "p1"},
        }
        ids.append(mid)

    # 批量写入 SQLite documents 表
    if engine.db_connection is not None:
        for mid in ids:
            doc = faiss.docs[mid]
            await engine.db_connection.execute(
                "INSERT INTO documents (id, doc_id, text, metadata, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
                (
                    doc["id"],
                    doc["doc_id"],
                    doc["text"],
                    json.dumps(doc["metadata"], ensure_ascii=False),
                ),
            )
            await engine.db_connection.commit()
            await engine.save_memory_source(
                mid,
                [{"role": "user", "content": f"source-{mid}"}],
            )

    deleted = await engine.batch_delete_memories(ids)
    assert deleted == 5

    # FAISS 中的记录应被清除
    for mid in ids:
        assert mid not in faiss.docs
        assert await engine.get_memory(mid) is None

    # SQLite documents 表也应被清空
    cursor = await engine.db_connection.execute(
        f"SELECT COUNT(*) FROM documents WHERE id IN ({','.join('?' * len(ids))})",
        ids,
    )
    row = await cursor.fetchone()
    assert row[0] == 0

    cursor = await engine.db_connection.execute(
        f"SELECT COUNT(*) FROM memory_sources WHERE memory_id IN ({','.join('?' * len(ids))})",
        ids,
    )
    row = await cursor.fetchone()
    assert row[0] == 0

    await engine.close()


@pytest.mark.asyncio
async def test_batch_delete_memories_empty_list_returns_zero(tmp_path: Path):
    """空列表传入 batch_delete_memories 应返回 0。"""
    db_path = tmp_path / "batch_del_empty.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()
    assert await engine.batch_delete_memories([]) == 0
    await engine.close()


@pytest.mark.asyncio
async def test_batch_delete_memories_nonexistent_ids_are_noop(tmp_path: Path):
    """batch_delete_memories 传入不存在的 ID 不应报错，正常删除存在的部分。"""
    db_path = tmp_path / "batch_del_partial.db"
    faiss = _FakeFaissDB()
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=faiss,
        config={},
    )
    await engine.initialize()

    mid = 1
    faiss._next_id = 2
    faiss.docs[mid] = {
        "id": mid,
        "doc_id": f"uuid-{mid}",
        "text": "存在的记忆",
        "metadata": {"importance": 0.5},
    }

    if engine.db_connection is not None:
        await engine.db_connection.execute(
            "INSERT INTO documents (id, doc_id, text, metadata, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
            (mid, f"uuid-{mid}", "存在的记忆", json.dumps({"importance": 0.5})),
        )
        await engine.db_connection.commit()

    deleted = await engine.batch_delete_memories([mid, 99999, 99998])
    assert deleted == 1
    assert mid not in faiss.docs

    await engine.close()



@pytest.mark.asyncio
async def test_cleanup_old_memories_uses_batch_delete(tmp_path: Path):
    """cleanup_old_memories 应通过 batch_delete_memories 高效清理多条候选记忆。"""
    db_path = tmp_path / "cleanup_batch.db"
    faiss = _FakeFaissDB()
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=faiss,
        config={"cleanup_days_threshold": 0, "cleanup_importance_threshold": 0.3},
    )
    await engine.initialize()

    old_time = time.time() - 86400 * 10
    ids = []
    for i in range(10):
        mid = faiss._next_id
        faiss._next_id += 1
        faiss.docs[mid] = {
            "id": mid,
            "doc_id": f"uuid-{mid}",
            "text": f"待清理记忆{i}",
            "metadata": {
                "importance": 0.1,
                "create_time": old_time,
                "session_id": "s1",
            },
        }
        ids.append(mid)

    if engine.db_connection is not None:
        for mid in ids:
            doc = faiss.docs[mid]
            await engine.db_connection.execute(
                "INSERT INTO documents (id, doc_id, text, metadata, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
                (
                    doc["id"],
                    doc["doc_id"],
                    doc["text"],
                    json.dumps(doc["metadata"], ensure_ascii=False),
                ),
            )
        await engine.db_connection.commit()

    deleted = await engine.cleanup_old_memories(
        days_threshold=1, importance_threshold=0.3
    )
    assert deleted == 10
    for mid in ids:
        assert mid not in faiss.docs

    await engine.close()


# ==================== 更新回滚测试 ====================


@pytest.mark.asyncio
async def test_update_memory_rollback_on_delete_failure(tmp_path: Path):
    """delete_memory 失败时应回滚删除新创建的记忆并返回 False。"""
    db_path = tmp_path / "update_rollback.db"
    engine = MemoryEngine(db_path=str(db_path), faiss_db=_FakeFaissDB(), config={})
    await engine.initialize()

    old_id = await engine.add_memory(
        content="旧内容",
        session_id="s1",
        persona_id="p1",
        importance=0.7,
        metadata={},
    )

    original_delete = engine.delete_memory
    call_count = 0
    deleted_ids = []

    async def fake_delete(memory_id):
        nonlocal call_count
        call_count += 1
        deleted_ids.append(memory_id)
        if call_count == 1:
            return False
        return await original_delete(memory_id)

    engine.delete_memory = fake_delete

    success = await engine.update_memory(old_id, {"content": "新内容"})
    assert success is False
    assert call_count == 2
    old_mem = await engine.get_memory(old_id)
    assert old_mem is not None

    await engine.close()


@pytest.mark.asyncio
async def test_update_memory_add_fails_returns_false(tmp_path: Path):
    """add_memory 返回 None 时，update_memory 应返回 False 且不调用 delete。"""
    db_path = tmp_path / "update_addfail.db"
    engine = MemoryEngine(db_path=str(db_path), faiss_db=_FakeFaissDB(), config={})
    await engine.initialize()

    old_id = await engine.add_memory(
        content="旧内容",
        session_id="s1",
        persona_id="p1",
        importance=0.7,
        metadata={},
    )

    delete_called = False

    async def fake_add(*args, **kwargs):
        return None

    async def fake_delete(*args, **kwargs):
        nonlocal delete_called
        delete_called = True
        return True

    engine.add_memory = fake_add
    engine.delete_memory = fake_delete

    success = await engine.update_memory(old_id, {"content": "新内容"})
    assert success is False
    assert delete_called is False

    await engine.close()


@pytest.mark.asyncio
async def test_replace_memory_rebuilds_atoms_and_preserves_create_time(tmp_path: Path):
    engine = MemoryEngine(
        db_path=str(tmp_path / "replace_structured.db"),
        faiss_db=_FakeFaissDB(),
        graph_vector_db=_FakeFaissDB(),
        config={"atom_enabled": True, "graph_memory_enabled": True},
    )
    await engine.initialize()
    old_id = await engine.add_memory(
        content="old summary",
        session_id="s1",
        persona_id="p1",
        importance=0.5,
        metadata={"topics": ["old"], "key_facts": ["old fact"]},
    )
    old_memory = await engine.get_memory(old_id)
    old_create_time = old_memory["metadata"]["create_time"]

    new_id = await engine.replace_memory(
        old_id,
        content="new summary",
        importance=0.8,
        metadata={
            "topics": ["release"],
            "key_facts": ["Release is Friday"],
        },
    )

    assert new_id != old_id
    assert await engine.get_memory(old_id) is None
    replacement = await engine.get_memory(new_id)
    assert replacement["metadata"]["topics"] == ["release"]
    assert replacement["metadata"]["key_facts"] == ["Release is Friday"]
    assert replacement["metadata"]["create_time"] == old_create_time
    atoms = await engine.atom_store.get_by_parent(new_id)
    assert [atom.content for atom in atoms] == ["Release is Friday"]
    assert atoms[0].entities == ["release"]
    old_graph = await engine.graph_store.get_subgraph_for_memories([old_id])
    new_graph = await engine.graph_store.get_subgraph_for_memories([new_id])
    assert old_graph["entries"] == []
    assert any(
        "Release is Friday" in entry["content"]
        for entry in new_graph["entries"]
    )

    await engine.close()


@pytest.mark.asyncio
async def test_replace_memory_cancellation_removes_new_record(tmp_path: Path):
    engine = MemoryEngine(
        db_path=str(tmp_path / "replace_cancelled.db"),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()
    old_id = await engine.add_memory(content="old summary", metadata={})
    expected_new_id = old_id + 1
    original_delete = engine.delete_memory
    old_delete_started = asyncio.Event()
    deleted_ids: list[int] = []

    async def block_old_delete(memory_id: int) -> bool:
        deleted_ids.append(memory_id)
        if memory_id == old_id:
            old_delete_started.set()
            await asyncio.Future()
        return await original_delete(memory_id)

    engine.delete_memory = block_old_delete
    task = asyncio.create_task(
        engine.replace_memory(
            old_id,
            content="new summary",
            metadata={"topics": ["new"], "key_facts": ["new fact"]},
            importance=0.7,
        )
    )
    await asyncio.wait_for(old_delete_started.wait(), timeout=1)
    task.cancel()

    with pytest.raises(asyncio.CancelledError):
        await task

    assert deleted_ids == [old_id, expected_new_id]
    assert await engine.get_memory(old_id) is not None
    assert await engine.get_memory(expected_new_id) is None
    await engine.close()


# ==================== 分批加载测试 ====================


@pytest.mark.asyncio
async def test_get_session_memories_batch_pagination(tmp_path: Path):
    """超过 500 条记忆时应分批加载，metadata 应正确规范化。"""
    db_path = tmp_path / "batch_session.db"
    faiss = _FakeFaissDB()
    engine = MemoryEngine(db_path=str(db_path), faiss_db=faiss, config={})
    await engine.initialize()

    session_id = "test:private:batch-session"
    for i in range(501):
        mid = faiss._next_id
        faiss._next_id += 1
        create_time = 1000.0 + i
        metadata = {
            "importance": 0.5,
            "session_id": session_id,
            "create_time": create_time,
        }
        faiss.docs[mid] = {
            "id": mid,
            "doc_id": f"uuid-{mid}",
            "text": f"测试记忆内容 {i}",
            "metadata": dict(metadata),
        }
        if engine.db_connection is not None:
            await engine.db_connection.execute(
                "INSERT INTO documents (id, doc_id, text, metadata, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
                (
                    mid,
                    f"uuid-{mid}",
                    f"测试记忆内容 {i}",
                    json.dumps(metadata, ensure_ascii=False),
                ),
            )
    if engine.db_connection is not None:
        await engine.db_connection.commit()

    memories = await engine.get_session_memories(session_id, limit=10)
    assert len(memories) <= 10
    if len(memories) >= 2:
        for i in range(len(memories) - 1):
            t1 = memories[i]["metadata"].get("create_time", 0)
            t2 = memories[i + 1]["metadata"].get("create_time", 0)
            assert t1 >= t2

    for mem in memories:
        assert isinstance(mem["metadata"], dict)

    await engine.close()


# ==================== 批量删除边界测试 ====================


@pytest.mark.asyncio
async def test_batch_delete_clears_fts_index(tmp_path: Path):
    """批量删除应同时清除 livingmemory_memories_fts 和 documents 表中的记录。"""
    db_path = tmp_path / "batch_del_fts.db"
    faiss = _FakeFaissDB()
    engine = MemoryEngine(db_path=str(db_path), faiss_db=faiss, config={})
    await engine.initialize()

    ids = []
    for i in range(3):
        mid = faiss._next_id
        faiss._next_id += 1
        faiss.docs[mid] = {
            "id": mid,
            "doc_id": f"uuid-{mid}",
            "text": f"test fts {i}",
            "metadata": {"importance": 0.5, "session_id": "s1"},
        }
        ids.append(mid)

    if engine.db_connection is not None:
        for mid in ids:
            doc = faiss.docs[mid]
            await engine.db_connection.execute(
                "INSERT INTO documents (id, doc_id, text, metadata, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
                (
                    doc["id"],
                    doc["doc_id"],
                    doc["text"],
                    json.dumps(doc["metadata"], ensure_ascii=False),
                ),
            )
            await engine.db_connection.execute(
                "INSERT INTO livingmemory_memories_fts(doc_id, content) VALUES (?, ?)",
                (mid, doc["text"]),
            )
        await engine.db_connection.commit()

    deleted = await engine.batch_delete_memories(ids)
    assert deleted == 3

    if engine.db_connection is not None:
        for mid in ids:
            cursor = await engine.db_connection.execute(
                "SELECT COUNT(*) FROM livingmemory_memories_fts WHERE doc_id = ?",
                (mid,),
            )
            row = await cursor.fetchone()
            assert row[0] == 0

    await engine.close()



@pytest.mark.asyncio
async def test_concurrent_access_time_updates_do_not_lose_counts(tmp_path: Path):
    """并发访问时间更新应原子递增 access_count，不产生丢失更新。"""
    engine = MemoryEngine(
        db_path=str(tmp_path / "concurrent_access.db"),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()

    memory_id = 1
    await engine.db_connection.execute(
        """
        INSERT OR REPLACE INTO documents(id, doc_id, text, metadata, created_at, updated_at)
        VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
        """,
        (
            memory_id,
            "uuid-1",
            "并发访问",
            json.dumps({"importance": 0.5, "last_access_time": 0, "access_count": 0}),
        ),
    )
    await engine.db_connection.commit()

    await asyncio.gather(
        *[engine._update_access_time_internal(memory_id) for _ in range(20)]
    )

    cursor = await engine.db_connection.execute(
        "SELECT metadata FROM documents WHERE id = ?", (memory_id,)
    )
    row = await cursor.fetchone()
    assert json.loads(row["metadata"])["access_count"] == 20

    await engine.close()


@pytest.mark.asyncio
async def test_get_session_memories_sorted_by_create_time_desc(tmp_path: Path):
    """get_session_memories 应按 session_id 过滤并按 create_time 降序返回。"""
    engine = MemoryEngine(
        db_path=str(tmp_path / "session_sort.db"),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()

    now = time.time()
    for i in range(3):
        await engine.db_connection.execute(
            """
            INSERT INTO documents(id, doc_id, text, metadata, created_at, updated_at)
            VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
            """,
            (
                i + 1,
                f"uuid-{i + 1}",
                f"memory-{i}",
                json.dumps({"session_id": "s1", "create_time": now + i}),
            ),
        )
    await engine.db_connection.execute(
        """
        INSERT INTO documents(id, doc_id, text, metadata, created_at, updated_at)
        VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
        """,
        (
            100,
            "uuid-100",
            "other-session",
            json.dumps({"session_id": "s2", "create_time": now + 100}),
        ),
    )
    await engine.db_connection.commit()

    memories = await engine.get_session_memories("s1", limit=10)

    assert [m["id"] for m in memories] == [3, 2, 1]
    assert all(m["metadata"]["session_id"] == "s1" for m in memories)

    await engine.close()


@pytest.mark.asyncio
async def test_update_memory_status_only_skips_graph_reindex(tmp_path: Path):
    """纯状态编辑不应触发图谱整图重建（审计 M3 回归守卫）。"""
    db_path = tmp_path / "update_skip_graph.db"
    engine = MemoryEngine(
        db_path=str(db_path),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()

    mid = await engine.add_memory(
        content="测试记忆",
        session_id="s1",
        persona_id="p1",
        importance=0.5,
        metadata={},
    )

    from unittest.mock import AsyncMock, Mock

    engine.graph_memory_manager = Mock()
    engine.graph_memory_manager.index_memory = AsyncMock()
    engine.index_writer = Mock()
    engine.index_writer.update_metadata = AsyncMock(return_value=True)

    await engine.update_memory(mid, {"metadata": {"status": "archived"}})
    engine.graph_memory_manager.index_memory.assert_not_awaited()

    # importance 参与图谱打分，仍必须重建
    await engine.update_memory(mid, {"importance": 0.9})
    engine.graph_memory_manager.index_memory.assert_awaited_once()

    await engine.close()


class TestMemoryEngineDocumentQueries:
    """针对 MemoryEngine 新增的文档读侧方法的 SQL 行为验证。"""

    @staticmethod
    def _make_engine(db_path: str) -> MemoryEngine:
        """构造只初始化 db_connection 的最小引擎实例。"""
        engine = MemoryEngine.__new__(MemoryEngine)
        engine.db_connection = None
        engine.db_path = db_path
        return engine

    @staticmethod
    async def _create_documents_table(db: "aiosqlite.Connection") -> None:
        await db.execute(
            """
            CREATE TABLE documents (
                id INTEGER PRIMARY KEY,
                doc_id TEXT,
                text TEXT,
                metadata TEXT,
                created_at TEXT,
                updated_at TEXT
            )
            """
        )

    @staticmethod
    def _seed_rows() -> list[tuple[int, str, str, dict]]:
        return [
            (
                1,
                "1",
                "low preference",
                {"memory_type": "PREFERENCE", "importance": 0.3, "create_time": 10},
            ),
            (
                2,
                "2",
                "high preference",
                {"memory_type": "PREFERENCE", "importance": 0.9, "create_time": 20},
            ),
            (
                3,
                "3",
                "other fact",
                {
                    "memory_type": "FACT",
                    "importance": 1.0,
                    "create_time": 30,
                    "session_id": "s1",
                    "status": "active",
                },
            ),
        ]

    @staticmethod
    async def _seed_db(db_path: str) -> None:
        async with aiosqlite.connect(db_path) as db:
            await TestMemoryEngineDocumentQueries._create_documents_table(db)
            for (
                memory_id,
                doc_id,
                text,
                metadata,
            ) in TestMemoryEngineDocumentQueries._seed_rows():
                await db.execute(
                    """
                    INSERT INTO documents
                        (id, doc_id, text, metadata, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        memory_id,
                        doc_id,
                        text,
                        json.dumps(metadata),
                        "created",
                        "updated",
                    ),
                )
            await db.commit()

    @staticmethod
    async def _connect_engine(db_path: str) -> MemoryEngine:
        engine = TestMemoryEngineDocumentQueries._make_engine(db_path)
        engine.db_connection = await aiosqlite.connect(db_path)
        engine.db_connection.row_factory = aiosqlite.Row
        return engine

    @pytest.mark.asyncio
    async def test_list_memories_page_type_filter_and_sort(self, tmp_path):
        db_path = str(tmp_path / "memories.db")
        await self._seed_db(db_path)
        engine = await self._connect_engine(db_path)
        try:
            result = await engine.list_memories_page(
                memory_type="PREFERENCE", sort_key="importance_desc"
            )
        finally:
            await engine.db_connection.close()

        assert result["total"] == 2
        assert result["sort"] == "importance_desc"
        assert [item["id"] for item in result["items"]] == [2, 1]

    @pytest.mark.asyncio
    async def test_list_memories_page_filters_and_pagination(self, tmp_path):
        db_path = str(tmp_path / "memories.db")
        await self._seed_db(db_path)
        engine = await self._connect_engine(db_path)
        try:
            session_page = await engine.list_memories_page(session_id="s1")
            assert session_page["total"] == 1
            assert [item["id"] for item in session_page["items"]] == [3]

            status_page = await engine.list_memories_page(status="active")
            # 未写 status 的行按默认值视为 active，三条全部命中
            assert status_page["total"] == 3

            keyword_page = await engine.list_memories_page(keyword="3")
            assert keyword_page["total"] == 1
            assert keyword_page["items"][0]["id"] == 3

            text_page = await engine.list_memories_page(keyword="preference")
            assert text_page["total"] == 2

            paged = await engine.list_memories_page(page=2, page_size=2)
            # created_desc 全序为 [3, 2, 1]，第 2 页只剩 id=1
            assert paged["total"] == 3
            assert [item["id"] for item in paged["items"]] == [1]
            assert paged["has_more"] is False

            unknown_sort = await engine.list_memories_page(sort_key="bogus")
            assert unknown_sort["sort"] == "created_desc"
        finally:
            await engine.db_connection.close()

    @pytest.mark.asyncio
    async def test_list_memories_page_requires_connection(self, tmp_path):
        engine = self._make_engine(str(tmp_path / "memories.db"))
        with pytest.raises(RuntimeError):
            await engine.list_memories_page()

    @pytest.mark.asyncio
    async def test_get_memory_record(self, tmp_path):
        db_path = str(tmp_path / "memories.db")
        await self._seed_db(db_path)
        engine = await self._connect_engine(db_path)
        try:
            record = await engine.get_memory_record(2)
            missing = await engine.get_memory_record(999)
        finally:
            await engine.db_connection.close()

        assert record is not None
        assert record["id"] == 2
        assert record["doc_id"] == "2"
        assert record["text"] == "high preference"
        assert record["created_at"] == "created"
        assert record["updated_at"] == "updated"
        assert missing is None

    @pytest.mark.asyncio
    async def test_get_consolidation_candidates(self, tmp_path):
        db_path = str(tmp_path / "memories.db")
        await self._seed_db(db_path)
        engine = await self._connect_engine(db_path)
        try:
            # importance < 0.5 且 create_time < 100：仅 id=1 命中
            candidates = await engine.get_consolidation_candidates(0.5, 100.0)
            all_rows = await engine.get_consolidation_candidates(1.1, 10**9)
        finally:
            await engine.db_connection.close()

        assert [c["id"] for c in candidates] == [1]
        assert candidates[0]["content"] == "low preference"
        assert candidates[0]["metadata"]["memory_type"] == "PREFERENCE"
        assert [c["id"] for c in all_rows] == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_get_consolidation_stats(self, tmp_path):
        db_path = str(tmp_path / "memories.db")
        await self._seed_db(db_path)
        engine = await self._connect_engine(db_path)
        try:
            await engine.db_connection.execute(
                "INSERT INTO documents(text, metadata) VALUES ('merged', ?)",
                (json.dumps({"consolidated_from": [1, 2], "status": "active"}),),
            )
            await engine.db_connection.commit()

            stats = await engine.get_consolidation_stats()
        finally:
            await engine.db_connection.close()

        assert stats == {"consolidated_count": 1, "archived_count": 0}


@pytest.mark.asyncio
async def test_background_task_failure_is_logged(tmp_path: Path, monkeypatch):
    """后台任务异常必须被取回并记录，不能静默丢弃。"""
    import astrbot_plugin_livingmemory.core.managers.memory_engine as engine_mod

    engine = MemoryEngine(
        db_path=str(tmp_path / "bg_task.db"),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()
    fake_logger = Mock()
    monkeypatch.setattr(engine_mod, "logger", fake_logger)

    async def boom() -> None:
        raise RuntimeError("background boom")

    engine._create_tracked_task(boom())
    await asyncio.sleep(0.05)

    assert not engine._pending_tasks
    messages = [
        str(call.args[0]) for call in fake_logger.error.call_args_list if call.args
    ]
    assert any("后台任务失败" in message for message in messages)

    await engine.close()


@pytest.mark.asyncio
async def test_archive_marks_index_rebuild_when_vector_delete_unavailable(
    tmp_path: Path,
):
    """无法单独删除向量时，归档必须标记启动重建，避免幽灵向量挤占召回候选。"""
    from types import SimpleNamespace

    engine = MemoryEngine(
        db_path=str(tmp_path / "archive_flag.db"),
        faiss_db=_FakeFaissDB(),
        config={},
    )
    await engine.initialize()
    memory_id = await engine.add_memory("archivable memory", session_id="s1")

    # 模拟旧版 AstrBot：embedding_storage 没有 delete 方法
    engine.faiss_db.embedding_storage = SimpleNamespace()

    archived = await engine.archive_memories([memory_id])
    assert archived == 1

    cursor = await engine.db_connection.execute(
        "SELECT value FROM migration_status WHERE key = 'needs_index_rebuild'"
    )
    row = await cursor.fetchone()
    assert row is not None and row[0] == "true"

    await engine.close()
