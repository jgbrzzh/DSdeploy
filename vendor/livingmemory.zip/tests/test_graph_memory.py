"""Tests for graph-memory indexing and dual-route retrieval."""

import asyncio
import json
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from astrbot_plugin_livingmemory.core.managers.graph_memory_manager import (
    GraphMemoryManager,
)
from astrbot_plugin_livingmemory.core.managers.memory_engine import MemoryEngine
from astrbot_plugin_livingmemory.core.models.graph_models import (
    GraphEdge,
    GraphEntry,
    GraphNode,
)
from astrbot_plugin_livingmemory.core.processors.graph_extractor import GraphExtractor
from astrbot_plugin_livingmemory.core.processors.text_processor import TextProcessor
from astrbot_plugin_livingmemory.core.retrieval.graph_keyword_retriever import (
    GraphKeywordRetriever,
)
from astrbot_plugin_livingmemory.core.retrieval.graph_retriever import GraphRetriever
from astrbot_plugin_livingmemory.core.retrieval.graph_vector_retriever import (
    GraphVectorRetriever,
)
from astrbot_plugin_livingmemory.core.retrieval.rrf_fusion import RRFFusion
from astrbot_plugin_livingmemory.storage.graph_store import GraphStore


@dataclass
class _FakeRetrieveResult:
    similarity: float
    data: dict


class _FakeDocumentStorage:
    def __init__(self, db: "_FakeFaissDB"):
        self._db = db

    async def get_documents(self, metadata_filters, ids=None, limit=50, offset=0):
        docs = list(self._db.docs.values())
        if ids is not None:
            id_set = set(ids)
            docs = [doc for doc in docs if doc["id"] in id_set]

        for key, value in (metadata_filters or {}).items():
            docs = [doc for doc in docs if doc["metadata"].get(key) == value]

        docs = docs[offset : offset + limit]
        return [dict(doc) for doc in docs]

    async def count_documents(self, metadata_filters):
        docs = list(self._db.docs.values())
        for key, value in (metadata_filters or {}).items():
            docs = [doc for doc in docs if doc["metadata"].get(key) == value]
        return len(docs)


class _FakeFaissDB:
    def __init__(self):
        self.docs: dict[int, dict] = {}
        self._next_id = 1
        self.insert_batch_calls = 0
        self.delete_documents_calls = 0
        self.document_storage = _FakeDocumentStorage(self)

    async def insert(self, content: str, metadata: dict) -> int:
        doc_id = self._next_id
        self._next_id += 1
        self.docs[doc_id] = {
            "id": doc_id,
            "doc_id": f"uuid-{doc_id}",
            "text": content,
            "metadata": dict(metadata),
        }
        return doc_id

    async def insert_batch(self, contents: list[str], metadatas: list[dict]):
        self.insert_batch_calls += 1
        return [
            await self.insert(content, metadata)
            for content, metadata in zip(contents, metadatas, strict=True)
        ]

    async def retrieve(
        self, query: str, k: int, fetch_k: int, rerank: bool, metadata_filters=None
    ):
        results: list[_FakeRetrieveResult] = []
        for doc in self.docs.values():
            if metadata_filters:
                matched = True
                for key, value in metadata_filters.items():
                    if doc["metadata"].get(key) != value:
                        matched = False
                        break
                if not matched:
                    continue

            text = doc["text"]
            score = 0.9 if query in text else 0.2
            results.append(
                _FakeRetrieveResult(
                    similarity=score,
                    data={
                        "id": doc["id"],
                        "text": text,
                        "metadata": dict(doc["metadata"]),
                    },
                )
            )

        results.sort(key=lambda item: item.similarity, reverse=True)
        return results[:k]

    async def delete(self, uuid_doc_id: str) -> None:
        target = None
        for doc_id, doc in self.docs.items():
            if doc["doc_id"] == uuid_doc_id:
                target = doc_id
                break
        if target is not None:
            self.docs.pop(target, None)

    async def delete_documents(self, metadata_filters: dict) -> None:
        self.delete_documents_calls += 1
        matching_ids = [
            doc_id
            for doc_id, doc in self.docs.items()
            if all(
                doc["metadata"].get(key) == value
                for key, value in metadata_filters.items()
            )
        ]
        for doc_id in matching_ids:
            self.docs.pop(doc_id, None)

    async def close(self) -> None:
        return None


@pytest.mark.asyncio
async def test_graph_vector_retriever_uses_bulk_faiss_operations():
    vector_db = SimpleNamespace(
        insert_batch=AsyncMock(return_value=[11]),
        delete_documents=AsyncMock(),
    )
    retriever = GraphVectorRetriever(vector_db)

    ids = await retriever.add_entries(
        [
            ("entry one", {"source_memory_id": 7}),
            ("entry two", {"source_memory_id": 7}),
        ]
    )
    await retriever.delete_entries(7, ids)

    assert ids == [11]
    vector_db.insert_batch.assert_awaited_once_with(
        contents=["entry one\nentry two"],
        metadatas=[
            {
                "source_memory_id": 7,
                "graph_vector_granularity": "memory",
                "graph_entry_count": 2,
            }
        ],
    )
    vector_db.delete_documents.assert_awaited_once_with(
        metadata_filters={"source_memory_id": 7}
    )


@pytest.mark.asyncio
async def test_graph_vector_retriever_batches_multiple_memories_in_one_save():
    vector_db = SimpleNamespace(insert_batch=AsyncMock(return_value=[11, 12]))
    retriever = GraphVectorRetriever(vector_db)

    ids = await retriever.add_memory_entries_batch(
        [
            [("memory one topic", {"source_memory_id": 7})],
            [
                ("memory two topic", {"source_memory_id": 8}),
                ("memory two fact", {"source_memory_id": 8}),
            ],
        ]
    )

    assert ids == [11, 12]
    vector_db.insert_batch.assert_awaited_once()
    call = vector_db.insert_batch.await_args.kwargs
    assert call["contents"] == [
        "memory one topic",
        "memory two topic\nmemory two fact",
    ]
    assert [metadata["source_memory_id"] for metadata in call["metadatas"]] == [
        7,
        8,
    ]


@pytest.mark.asyncio
async def test_graph_vector_retriever_skips_empty_bulk_delete():
    vector_db = SimpleNamespace(delete_documents=AsyncMock())
    retriever = GraphVectorRetriever(vector_db)

    await retriever.delete_entries(7, [])

    vector_db.delete_documents.assert_not_awaited()


@pytest.mark.asyncio
async def test_graph_vector_retriever_batches_multiple_source_deletes():
    document_storage = SimpleNamespace(
        get_documents=AsyncMock(
            return_value=[
                {"id": 11, "doc_id": "uuid-11"},
                {"id": 12, "doc_id": "uuid-12"},
            ]
        ),
        delete_document_by_doc_id=AsyncMock(),
    )
    embedding_storage = SimpleNamespace(delete=AsyncMock())
    retriever = GraphVectorRetriever(
        SimpleNamespace(
            document_storage=document_storage,
            embedding_storage=embedding_storage,
        )
    )

    await retriever.delete_entries_batch({7: [11], 8: [12]})

    embedding_storage.delete.assert_awaited_once_with([11, 12])
    assert document_storage.delete_document_by_doc_id.await_count == 2


@pytest.mark.asyncio
async def test_graph_memory_manager_indexes_nodes_edges_and_entries(tmp_path: Path):
    db_path = tmp_path / "graph_memory.db"
    graph_store = GraphStore(str(db_path))
    await graph_store.initialize()

    vector_db = _FakeFaissDB()
    graph_manager = GraphMemoryManager(
        graph_store=graph_store,
        graph_vector_retriever=GraphVectorRetriever(vector_db),
        graph_extractor=GraphExtractor(),
    )

    metadata = {
        "session_id": "test:private:s1",
        "persona_id": "persona_1",
        "importance": 0.8,
        "create_time": 1.0,
        "last_access_time": 1.0,
        "canonical_summary": "项目会议安排在明天下午三点",
        "topics": ["项目会议"],
        "participants": ["张三", "李四"],
        "key_facts": ["明天下午三点开会"],
    }

    await graph_manager.index_memory(1, metadata["canonical_summary"], metadata)

    stats = await graph_store.get_memory_entry_stats()
    assert stats["graph_nodes"] >= 4
    assert stats["graph_edges"] >= 3
    assert stats["graph_entries"] >= 4
    assert len(vector_db.docs) == 1
    vector_doc = next(iter(vector_db.docs.values()))
    assert vector_doc["metadata"]["graph_vector_granularity"] == "memory"
    assert vector_doc["metadata"]["graph_entry_count"] == stats["graph_entries"]


@pytest.mark.asyncio
async def test_graph_rebuild_failure_preserves_live_generation(
    tmp_path: Path, monkeypatch
):
    graph_store = GraphStore(str(tmp_path / "graph_rebuild_failure.db"))
    await graph_store.initialize()
    vector_db = _FakeFaissDB()
    manager = GraphMemoryManager(
        graph_store=graph_store,
        graph_vector_retriever=GraphVectorRetriever(vector_db),
        graph_extractor=GraphExtractor(),
    )
    metadata = {
        "canonical_summary": "live generation",
        "topics": ["stable"],
        "participants": ["Alice"],
        "key_facts": ["old graph remains available"],
    }
    await manager.index_memory(1, "live generation", metadata)
    live_snapshot = await graph_store.get_subgraph_for_memories([1])
    live_vector_ids = set(vector_db.docs)

    monkeypatch.setattr(
        manager.graph_vector_retriever,
        "add_memory_entries_batch",
        AsyncMock(side_effect=RuntimeError("embedding failed")),
    )

    with pytest.raises(RuntimeError, match="embedding failed"):
        await manager.rebuild_memories(
            [(2, "shadow generation", {**metadata, "topics": ["new"]})]
        )

    assert await graph_store.get_subgraph_for_memories([1]) == live_snapshot
    assert set(vector_db.docs) == live_vector_ids


@pytest.mark.asyncio
async def test_graph_rebuild_replays_concurrent_changes(tmp_path: Path):
    graph_store = GraphStore(str(tmp_path / "graph_rebuild_delta.db"))
    await graph_store.initialize()
    vector_db = _FakeFaissDB()
    manager = GraphMemoryManager(
        graph_store=graph_store,
        graph_vector_retriever=GraphVectorRetriever(vector_db),
        graph_extractor=GraphExtractor(),
    )
    metadata = {
        "canonical_summary": "initial memory",
        "topics": ["initial"],
        "participants": ["Alice"],
        "key_facts": ["initial fact"],
    }
    await manager.index_memory(1, "initial memory", metadata)

    rebuild_started = asyncio.Event()
    finish_rebuild = asyncio.Event()

    async def batches():
        yield [(1, "initial memory", metadata)]
        rebuild_started.set()
        await finish_rebuild.wait()

    rebuild_task = asyncio.create_task(manager.rebuild_memory_batches(batches()))
    await rebuild_started.wait()
    await manager.delete_memory(1)
    await manager.index_memory(
        2,
        "concurrent memory",
        {
            **metadata,
            "canonical_summary": "concurrent memory",
            "topics": ["concurrent"],
        },
    )
    finish_rebuild.set()
    await rebuild_task

    assert not (await graph_store.get_subgraph_for_memories([1]))["memories"]
    snapshot = await graph_store.get_subgraph_for_memories([2])
    assert {item["memory_id"] for item in snapshot["memories"]} == {2}
    assert len(vector_db.docs) == 1


@pytest.mark.asyncio
async def test_graph_memory_manager_rejects_entry_id_mismatch(tmp_path: Path):
    db_path = tmp_path / "graph_memory_mismatch.db"
    graph_store = GraphStore(str(db_path))
    await graph_store.initialize()

    class MismatchedGraphStore:
        async def upsert_nodes(self, nodes):
            return await graph_store.upsert_nodes(nodes)

        async def add_edges(self, edges, node_key_to_id):
            return await graph_store.add_edges(edges, node_key_to_id)

        async def add_entries(self, entries, node_key_to_id, edge_key_to_id):
            entry_ids = await graph_store.add_entries(
                entries,
                node_key_to_id,
                edge_key_to_id,
            )
            return entry_ids[:-1]

        async def update_entry_vector_doc_ids(self, entry_vector_doc_ids):
            return await graph_store.update_entry_vector_doc_ids(entry_vector_doc_ids)

        async def delete_memory(self, source_memory_id):
            return await graph_store.delete_memory(source_memory_id)

    graph_manager = GraphMemoryManager(
        graph_store=MismatchedGraphStore(),
        graph_vector_retriever=GraphVectorRetriever(_FakeFaissDB()),
        graph_extractor=GraphExtractor(),
    )

    with pytest.raises(RuntimeError, match="graph entry id count mismatch"):
        await graph_manager.index_memory(
            1,
            "项目会议安排在明天下午三点",
            {
                "topics": ["项目会议"],
                "participants": ["张三"],
                "key_facts": ["明天下午三点开会"],
            },
        )


@pytest.mark.asyncio
async def test_graph_store_snapshot_builds_ui_ready_subgraphs(tmp_path: Path):
    db_path = tmp_path / "graph_snapshot.db"
    graph_store = GraphStore(str(db_path))
    await graph_store.initialize()

    manager = GraphMemoryManager(
        graph_store=graph_store,
        graph_vector_retriever=GraphVectorRetriever(_FakeFaissDB()),
        graph_extractor=GraphExtractor(),
    )

    await manager.index_memory(
        11,
        "Roadmap workshop with Alice",
        {
            "session_id": "test:private:s1",
            "persona_id": "persona_1",
            "importance": 0.82,
            "create_time": 10.0,
            "last_access_time": 12.0,
            "canonical_summary": "Roadmap workshop with Alice",
            "topics": ["roadmap"],
            "participants": ["Alice"],
            "key_facts": ["Finalize Q2 roadmap"],
        },
    )
    await manager.index_memory(
        12,
        "Deployment sync with Bob",
        {
            "session_id": "test:private:s1",
            "persona_id": "persona_1",
            "importance": 0.74,
            "create_time": 11.0,
            "last_access_time": 13.0,
            "canonical_summary": "Deployment sync with Bob",
            "topics": ["deployment"],
            "participants": ["Bob"],
            "key_facts": ["Prepare release checklist"],
        },
    )

    snapshot = await graph_store.get_graph_snapshot(session_id="test:private:s1")
    assert snapshot["nodes"]
    assert snapshot["edges"]
    assert snapshot["entries"]
    assert {memory["memory_id"] for memory in snapshot["memories"]} >= {11, 12}

    compact_snapshot = await graph_store.get_graph_snapshot(
        session_id="test:private:s1",
        limit_memories=1,
    )
    full_snapshot = await graph_store.get_full_graph_snapshot(
        session_id="test:private:s1"
    )
    assert {memory["memory_id"] for memory in full_snapshot["memories"]} == {11, 12}
    assert len(full_snapshot["memories"]) > len(compact_snapshot["memories"])
    assert len(full_snapshot["nodes"]) >= len(compact_snapshot["nodes"])
    assert len(full_snapshot["edges"]) >= len(compact_snapshot["edges"])

    focused = await graph_store.get_subgraph_for_memories([11])
    assert focused["memories"]
    assert focused["memories"][0]["memory_id"] == 11
    assert all(entry["memory_id"] == 11 for entry in focused["entries"])
    assert any(node["type"] == "person" for node in focused["nodes"])


@pytest.mark.asyncio
async def test_graph_retriever_supports_keyword_and_vector_search(tmp_path: Path):
    db_path = tmp_path / "graph_search.db"
    graph_store = GraphStore(str(db_path))
    await graph_store.initialize()
    vector_db = _FakeFaissDB()

    manager = GraphMemoryManager(
        graph_store=graph_store,
        graph_vector_retriever=GraphVectorRetriever(vector_db),
        graph_extractor=GraphExtractor(),
    )
    metadata = {
        "session_id": "test:private:s1",
        "persona_id": "persona_1",
        "importance": 0.7,
        "create_time": 1.0,
        "last_access_time": 1.0,
        "canonical_summary": "项目讨论记录",
        "topics": ["项目讨论"],
        "participants": ["张三"],
        "key_facts": ["明天下午三点开会"],
    }
    await manager.index_memory(5, metadata["canonical_summary"], metadata)

    text_processor = TextProcessor()
    retriever = GraphRetriever(
        keyword_retriever=GraphKeywordRetriever(graph_store, text_processor),
        vector_retriever=GraphVectorRetriever(vector_db),
        rrf_fusion=RRFFusion(60),
        config={},
    )

    results = await retriever.search("张三", k=3, session_id="test:private:s1")
    assert results
    assert results[0].doc_id == 5
    assert (results[0].keyword_score or 0) > 0

    results = await retriever.search(
        "明天下午三点开会", k=3, session_id="test:private:s1"
    )
    assert results
    assert results[0].doc_id == 5
    assert (results[0].vector_score or 0) > 0


@pytest.mark.asyncio
async def test_graph_keyword_retriever_supports_configurable_second_hop(
    tmp_path: Path,
):
    db_path = tmp_path / "graph_second_hop.db"
    graph_store = GraphStore(str(db_path))
    await graph_store.initialize()

    nodes = [
        GraphNode("person", "张三", "张三"),
        GraphNode("topic", "项目", "项目"),
        GraphNode("fact", "周五上线", "周五上线"),
    ]
    node_key_to_id = await graph_store.upsert_nodes(nodes)
    edges = [
        GraphEdge(
            source_key="person:张三",
            target_key="topic:项目",
            relation_type="mentioned_in",
            source_memory_id=1,
        ),
        GraphEdge(
            source_key="topic:项目",
            target_key="fact:周五上线",
            relation_type="describes",
            source_memory_id=2,
        ),
    ]
    edge_key_to_id = await graph_store.add_edges(edges, node_key_to_id)
    await graph_store.add_entries(
        [
            GraphEntry(
                entry_key="entry-1",
                source_memory_id=1,
                session_id="s1",
                persona_id="p1",
                entry_type="participant",
                content="Participant: 张三",
                metadata={"importance": 0.5},
                node_keys=["person:张三"],
                relation_type="participant",
            ),
            GraphEntry(
                entry_key="entry-2",
                source_memory_id=2,
                session_id="s1",
                persona_id="p1",
                entry_type="fact",
                content="Fact: 周五上线",
                metadata={"importance": 0.5},
                node_keys=["fact:周五上线"],
                relation_type="fact",
            ),
        ],
        node_key_to_id,
        edge_key_to_id,
    )

    retriever = GraphKeywordRetriever(
        graph_store,
        TextProcessor(),
        config={
            "graph_expansion_hops": 2,
            "graph_expansion_limit": 12,
            "graph_second_hop_weight": 0.4,
        },
    )

    results = await retriever.search("张三", limit=5, session_id="s1", persona_id="p1")
    assert {item.doc_id for item in results} >= {1, 2}
    second_hop = next(item for item in results if item.doc_id == 2)
    assert "graph_second_hop" in second_hop.metadata["graph_match_source"]


@pytest.mark.asyncio
async def test_memory_engine_dual_route_promotes_graph_hits(tmp_path: Path):
    doc_db_path = tmp_path / "memory.db"
    engine = MemoryEngine(
        db_path=str(doc_db_path),
        faiss_db=_FakeFaissDB(),
        graph_vector_db=_FakeFaissDB(),
        config={
            "fallback_enabled": True,
            "graph_memory_enabled": True,
            "document_route_weight": 0.6,
            "graph_route_weight": 0.4,
        },
    )
    await engine.initialize()

    matching_id = await engine.add_memory(
        content="项目讨论记录",
        session_id="test:private:s1",
        persona_id="persona_1",
        importance=0.8,
        metadata={
            "topics": ["项目讨论"],
            "participants": ["张三"],
            "key_facts": ["明天下午三点开会"],
            "canonical_summary": "项目讨论记录",
        },
    )
    other_id = await engine.add_memory(
        content="普通对话记录",
        session_id="test:private:s1",
        persona_id="persona_1",
        importance=0.5,
        metadata={
            "topics": ["闲聊"],
            "participants": ["王五"],
            "key_facts": ["天气不错"],
            "canonical_summary": "普通对话记录",
        },
    )

    assert matching_id != other_id

    results = await engine.search_memories(
        query="张三",
        k=2,
        session_id="test:private:s1",
        persona_id="persona_1",
    )
    assert results
    assert results[0].doc_id == matching_id
    assert (results[0].score_breakdown or {}).get("graph_keyword_score", 0.0) > 0

    await engine.close()


@pytest.mark.asyncio
async def test_memory_engine_rebuild_graph_index(tmp_path: Path):
    doc_db_path = tmp_path / "memory_rebuild.db"
    graph_vector_db = _FakeFaissDB()
    engine = MemoryEngine(
        db_path=str(doc_db_path),
        faiss_db=_FakeFaissDB(),
        graph_vector_db=graph_vector_db,
        config={"fallback_enabled": True, "graph_memory_enabled": True},
    )
    await engine.initialize()

    memory_id = await engine.add_memory(
        content="项目讨论记录",
        session_id="test:private:s1",
        persona_id="persona_1",
        importance=0.8,
        metadata={
            "topics": ["项目讨论"],
            "participants": ["张三"],
            "key_facts": ["明天下午三点开会"],
            "canonical_summary": "项目讨论记录",
        },
    )
    assert memory_id > 0

    # The lightweight FAISS fake does not persist its document row in SQLite.
    # Graph rebuild deliberately streams from SQLite as the source of truth.
    source_doc = engine.faiss_db.docs[memory_id]
    await engine.db_connection.execute(
        """
        INSERT OR REPLACE INTO documents(id, doc_id, text, metadata)
        VALUES (?, ?, ?, ?)
        """,
        (
            memory_id,
            source_doc["doc_id"],
            source_doc["text"],
            json.dumps(source_doc["metadata"], ensure_ascii=False),
        ),
    )
    archived_id = memory_id + 100
    await engine.db_connection.execute(
        """
        INSERT INTO documents(id, doc_id, text, metadata)
        VALUES (?, ?, ?, ?)
        """,
        (
            archived_id,
            f"archived-{archived_id}",
            "不应进入图谱重建",
            json.dumps(
                {
                    **source_doc["metadata"],
                    "status": "archived",
                    "canonical_summary": "不应进入图谱重建",
                },
                ensure_ascii=False,
            ),
        ),
    )
    await engine.db_connection.commit()

    assert engine.graph_memory_manager is not None
    await engine.graph_memory_manager.delete_memory(memory_id)

    graph_vector_db.insert_batch_calls = 0
    graph_vector_db.delete_documents_calls = 0

    rebuild_result = await engine.rebuild_graph_index()
    assert rebuild_result == {"rebuilt": 1, "skipped": 0}
    assert graph_vector_db.delete_documents_calls == 0
    assert graph_vector_db.insert_batch_calls == 1
    assert len(graph_vector_db.docs) == rebuild_result["rebuilt"]

    stats = await engine.get_statistics()
    assert stats.get("graph_entries", 0) >= 1
    archived_graph = await engine.graph_store.get_subgraph_for_memories([archived_id])
    assert not archived_graph["memories"]
    await engine.close()


@pytest.mark.asyncio
async def test_memory_engine_streams_active_graph_rebuild_batches(tmp_path: Path):
    engine = MemoryEngine(
        db_path=str(tmp_path / "memory_stream_rebuild.db"),
        faiss_db=_FakeFaissDB(),
        graph_vector_db=_FakeFaissDB(),
        config={"fallback_enabled": True, "graph_memory_enabled": True},
    )
    await engine.initialize()
    rows = []
    for memory_id in range(1, 406):
        status = "archived" if memory_id > 400 else "active"
        rows.append(
            (
                memory_id,
                f"doc-{memory_id}",
                f"memory {memory_id}",
                json.dumps({"status": status}),
            )
        )
    await engine.db_connection.executemany(
        "INSERT INTO documents(id, doc_id, text, metadata) VALUES (?, ?, ?, ?)",
        rows,
    )
    await engine.db_connection.commit()

    class RecordingGraphManager:
        def __init__(self):
            self.batch_sizes = []
            self.memory_ids = []

        async def rebuild_memory_batches(self, batches):
            async for batch in batches:
                self.batch_sizes.append(len(batch))
                self.memory_ids.extend(memory_id for memory_id, _, _ in batch)
            return {"rebuilt": len(self.memory_ids), "skipped": 0}

    recorder = RecordingGraphManager()
    engine.graph_memory_manager = recorder
    result = await engine.rebuild_graph_index()

    assert result == {"rebuilt": 400, "skipped": 0}
    assert recorder.batch_sizes == [200, 200]
    assert recorder.memory_ids == list(range(1, 401))
    await engine.close()


@pytest.mark.asyncio
async def test_graph_store_batch_delete_memories(tmp_path: Path):
    """GraphStore.batch_delete_memories 应一次删除多条 source_memory 的图数据。"""
    doc_db_path = tmp_path / "graph_batch_del.db"
    engine = MemoryEngine(
        db_path=str(doc_db_path),
        faiss_db=_FakeFaissDB(),
        graph_vector_db=_FakeFaissDB(),
        config={"fallback_enabled": True, "graph_memory_enabled": True},
    )
    await engine.initialize()

    ids = []
    for i in range(3):
        mid = await engine.add_memory(
            content=f"批量图删除测试{i}：讨论项目进度",
            session_id="test:private:s1",
            persona_id="persona_1",
            importance=0.8,
            metadata={
                "topics": ["项目"],
                "canonical_summary": f"批量图删除测试{i}",
            },
        )
        ids.append(mid)

    stats_before = await engine.graph_store.get_memory_entry_stats()

    assert engine.graph_memory_manager is not None
    await engine.graph_memory_manager.batch_delete_memories(ids)

    stats_after = await engine.graph_store.get_memory_entry_stats()
    assert stats_after["graph_entries"] < stats_before["graph_entries"]

    await engine.close()
